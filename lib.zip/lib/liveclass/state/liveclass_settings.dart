// ============================================================
// LIVECLASS — SETTINGS CONTROLLER (language + theme)
//
// GAP THIS CLOSES: `app_en.arb` / `app_hi.arb` already exist (691 / 478
// keys) — the l10n *resources* were always there — but nothing in the
// app ever let a user pick a language or a theme; `Locale`/`ThemeMode`
// were whatever the OS handed over, with no in-app control and nothing
// persisted. This controller is the single source of truth for both,
// backed by SharedPreferences so the choice survives an app restart.
//
// WIRING (do this once, at the app root):
//
//   final settings = LiveClassSettingsController();
//   await settings.load();
//   runApp(
//     AnimatedBuilder(
//       animation: settings,
//       builder: (_, __) => MaterialApp(
//         locale: settings.locale,
//         themeMode: settings.themeMode,
//         supportedLocales: AppLocalizations.supportedLocales,
//         localizationsDelegates: AppLocalizations.localizationsDelegates,
//         theme: lightTheme,      // your existing ColorScheme-based theme
//         darkTheme: darkTheme,   // your existing dark ColorScheme theme
//         home: ...,
//       ),
//     ),
//   );
//
// If this project already has a `ThemeService`/locale controller
// elsewhere (referenced from `ls_ui.dart` as `AppThemeTokens`), prefer
// wiring `LiveClassSettingsScreen` to that existing controller instead
// of this one, so there's a single source of truth — this class is
// deliberately self-contained so it drops in cleanly either way.
// ============================================================

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LiveClassSettingsController extends ChangeNotifier {
  static const _kLocaleKey = 'liveclass.locale';
  static const _kThemeModeKey = 'liveclass.theme_mode';

  /// Keep in sync with the locales actually shipped in `l10n/`.
  static const supportedLocales = [Locale('en'), Locale('hi')];

  Locale? _locale; // null = follow system, as long as system is supported
  ThemeMode _themeMode = ThemeMode.system;

  Locale? get locale => _locale;
  ThemeMode get themeMode => _themeMode;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_kLocaleKey);
    if (code != null) {
      _locale = supportedLocales.firstWhere(
        (l) => l.languageCode == code,
        orElse: () => supportedLocales.first,
      );
    }
    final mode = prefs.getString(_kThemeModeKey);
    _themeMode = switch (mode) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    notifyListeners();
  }

  Future<void> setLocale(Locale? locale) async {
    _locale = locale;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    if (locale == null) {
      await prefs.remove(_kLocaleKey);
    } else {
      await prefs.setString(_kLocaleKey, locale.languageCode);
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kThemeModeKey, mode.name);
  }
}
