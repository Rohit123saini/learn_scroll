// ============================================================
// LIVECLASS — ASSIGNMENTS SCREEN
//
// Backend surface used: GET/POST /assigmentss/?classroom=, GET/POST
// /submissions/?assigments=, POST /submissions/{id}/grade/ (teacher only).
// (Endpoint name `assigmentss` is the backend's own spelling — kept
// as-is here rather than silently renaming, since the API client and
// this screen must agree with what the server actually routes.)
// ============================================================

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../ls_ui.dart';
import '../../error_widgets.dart';
import '../api/liveclass_api.dart';

class AssignmentsScreen extends StatefulWidget {
  final LiveClassApi api;
  final int classroomId;
  final bool isTeacher;
  const AssignmentsScreen({super.key, required this.api, required this.classroomId, this.isTeacher = false});

  @override
  State<AssignmentsScreen> createState() => _AssignmentsScreenState();
}

class _AssignmentsScreenState extends State<AssignmentsScreen> {
  List<dynamic> _assignments = const [];
  bool _loading = true;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await widget.api.assignments(classroomId: widget.classroomId);
      setState(() {
        _assignments = data;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e;
        _loading = false;
      });
    }
  }

  Future<void> _openSubmissions(int assignmentId, String title) async {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _SubmissionsScreen(api: widget.api, assignmentId: assignmentId, title: title, isTeacher: widget.isTeacher),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: lsBg(context),
      appBar: lsAppBar(context, title: t.assignmentsTitle),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? ErrorStateWidget(title: t.couldNotLoadAssignments, retryLabel: t.retry, onRetry: _load)
                : _assignments.isEmpty
                    ? EmptyStateWidget(title: t.noAssignmentsYet, icon: Icons.assignment_outlined)
                    : ListView(children: _assignments.map((a) {
                        final m = a as Map<String, dynamic>;
                        return LsCard(
                          margin: const EdgeInsets.fromLTRB(kLsPad, 10, kLsPad, 0),
                          onTap: () => _openSubmissions(m['id'] as int, m['title']?.toString() ?? ''),
                          child: Row(children: [
                            Expanded(child: Text(m['title']?.toString() ?? '', style: LsType.head(context, size: 13.5))),
                            Icon(Icons.chevron_right_rounded, color: cs.onSurfaceVariant),
                          ]),
                        );
                      }).toList()),
      ),
    );
  }
}

class _SubmissionsScreen extends StatefulWidget {
  final LiveClassApi api;
  final int assignmentId;
  final String title;
  final bool isTeacher;
  const _SubmissionsScreen({required this.api, required this.assignmentId, required this.title, required this.isTeacher});

  @override
  State<_SubmissionsScreen> createState() => _SubmissionsScreenState();
}

class _SubmissionsScreenState extends State<_SubmissionsScreen> {
  List<dynamic> _submissions = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await widget.api.submissions(assignmentId: widget.assignmentId);
    setState(() {
      _submissions = data;
      _loading = false;
    });
  }

  Future<void> _grade(int submissionId) async {
    final t = AppLocalizations.of(context)!;
    final ctrl = TextEditingController();
    final marks = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t.gradeSubmissionTitle),
        content: TextField(controller: ctrl, keyboardType: const TextInputType.numberWithOptions(decimal: true)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(t.cancelCta)),
          TextButton(onPressed: () => Navigator.pop(context, double.tryParse(ctrl.text)), child: Text(t.saveCta)),
        ],
      ),
    );
    if (marks == null) return;
    await widget.api.gradeSubmission(submissionId, marks);
    _load();
  }

  /// Text-answer submission. `submissions/` also accepts a file per the
  /// backend, but the file-picker/upload wiring depends on which package
  /// (`file_picker`, `image_picker`, etc.) this project already pins for
  /// uploads elsewhere — plug that in here alongside `answer_text` once
  /// picked, rather than guessing a package this pass didn't confirm.
  /// Text answer, with an optional file attachment via `file_picker` —
  /// the most common Flutter package for this, used here as a reasonable
  /// default since no upload package was confirmed elsewhere in the
  /// project. Swap `FilePicker.platform.pickFiles()` below for whatever
  /// this project already uses if it's a different package.
  Future<void> _submitAnswer() async {
    final t = AppLocalizations.of(context)!;
    final ctrl = TextEditingController();
    PlatformFile? picked;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setStateDialog) => AlertDialog(
            title: Text(t.submitAnswerTitle),
            content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              TextField(controller: ctrl, maxLines: 4),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                icon: const Icon(Icons.attach_file_rounded, size: 16),
                label: Text(picked?.name ?? t.attachFileOptionalCta),
                onPressed: () async {
                  final result = await FilePicker.platform.pickFiles(withData: true);
                  if (result != null && result.files.isNotEmpty) {
                    setStateDialog(() => picked = result.files.first);
                  }
                },
              ),
            ]),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: Text(t.cancelCta)),
              TextButton(onPressed: () => Navigator.pop(context, true), child: Text(t.submitCta)),
            ],
          )),
    );
    if (ok != true) return;
    if (ctrl.text.trim().isEmpty && picked == null) return;
    try {
      if (picked != null && picked!.bytes != null) {
        await widget.api.submitAssignmentWithFile(
          assignmentId: widget.assignmentId,
          answerText: ctrl.text.trim().isEmpty ? null : ctrl.text.trim(),
          fileBytes: picked!.bytes!,
          fileName: picked!.name,
        );
      } else {
        await widget.api.submitAssignment({'assigments': widget.assignmentId, 'answer_text': ctrl.text.trim()});
      }
      _load();
    } catch (e) {
      if (mounted) lsSnack(context, e.toString(), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: lsBg(context),
      appBar: lsAppBar(context, title: widget.title),
      floatingActionButton: !widget.isTeacher
          ? FloatingActionButton.extended(icon: const Icon(Icons.upload_file_rounded), label: Text(t.submitCta), onPressed: _submitAnswer)
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _submissions.isEmpty
              ? EmptyStateWidget(title: t.noSubmissionsYet, icon: Icons.inbox_outlined)
              : ListView(children: _submissions.map((s) {
                  final m = s as Map<String, dynamic>;
                  return LsCard(
                    margin: const EdgeInsets.fromLTRB(kLsPad, 10, kLsPad, 0),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(m['student_name']?.toString() ?? '', style: TextStyle(fontSize: 13, color: cs.onSurface)),
                          if (m['marks'] != null) Text('${t.marksLabel}: ${m['marks']}', style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                        ]),
                      ),
                      if (widget.isTeacher && m['marks'] == null)
                        LsOutlineButton(label: t.gradeCta, onPressed: () => _grade(m['id'] as int)),
                    ]),
                  );
                }).toList()),
    );
  }
}
