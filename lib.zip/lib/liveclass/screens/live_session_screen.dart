// ============================================================
// LIVECLASS — LIVE SESSION SCREEN
//
// This is the in-room screen: video area + chat + hand-raise +
// reactions + captions + polls + (host-only) moderation controls.
//
// VIDEO: actual audio/video is LiveKit's job, not this screen's — call
// `api.joinSession(id)` to get `{token, url}` from
// ClassSessionViewSet.join(), then hand those to whatever LiveKit
// Flutter SDK version this project pins (livekit_client). The video
// surface below is left as a clearly-marked slot so wiring it up
// doesn't require restructuring this screen.
//
// LIVE UPDATES: chat/reactions/captions/hand-raise are all backed by
// real persisted endpoints (see GAP_ANALYSIS.md), polled here on a
// short timer as a working baseline. If this project already runs a
// Channels/WebSocket connection for the room (the backend has a
// consumer for it), swap `_poll()` for that stream and drop the timer
// — the REST calls stay correct either way since they're the same
// durable log the WS layer is reading from.
// ============================================================

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../ls_ui.dart';
import '../../error_widgets.dart';
import '../api/liveclass_api.dart';
import '../models/liveclass_models.dart';
import 'breakout_rooms_panel.dart';
import 'moderation_screen.dart';

class LiveSessionScreen extends StatefulWidget {
  final LiveClassApi api;
  final int sessionId;
  final int classroomId;
  final bool isHost;
  const LiveSessionScreen({
    super.key,
    required this.api,
    required this.sessionId,
    required this.classroomId,
    this.isHost = false,
  });

  @override
  State<LiveSessionScreen> createState() => _LiveSessionScreenState();
}

class _LiveSessionScreenState extends State<LiveSessionScreen> {
  Timer? _poller;
  bool _connecting = true;
  Object? _connectError;

  List<ChatMessage> _chat = const [];
  List<LivePoll> _polls = const [];
  bool _handRaised = false;
  Map<String, int> _reactionCounts = const {};
  bool _recording = false;
  final _chatCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _connect();
  }

  Future<void> _connect() async {
    setState(() {
      _connecting = true;
      _connectError = null;
    });
    try {
      // token/url for the LiveKit SDK — see file header.
      await widget.api.joinSession(widget.sessionId);
      await _poll();
      _poller = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
      setState(() => _connecting = false);
    } catch (e) {
      setState(() {
        _connectError = e;
        _connecting = false;
      });
    }
  }

  Future<void> _poll() async {
    try {
      final results = await Future.wait([
        widget.api.chatMessages(widget.sessionId),
        widget.api.polls(widget.sessionId),
        widget.api.reactions(widget.sessionId),
      ]);
      if (!mounted) return;
      setState(() {
        _chat = (results[0] as List).map((e) => ChatMessage.fromJson(e as Map<String, dynamic>)).toList();
        _polls = (results[1] as List).map((e) => LivePoll.fromJson(e as Map<String, dynamic>)).toList();
        _reactionCounts = (results[2]['counts'] as Map?)?.map((k, v) => MapEntry(k.toString(), v as int)) ?? const {};
      });
    } catch (_) {
      // A missed poll tick isn't fatal — next tick retries. Surfacing a
      // toast every 4s on a flaky connection would be worse than silence.
    }
  }

  @override
  void dispose() {
    _poller?.cancel();
    _chatCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendChat() async {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;
    _chatCtrl.clear();
    try {
      await widget.api.sendChatMessage(widget.sessionId, text);
      await _poll();
    } catch (_) {}
  }

  Future<void> _toggleHand() async {
    final next = !_handRaised;
    setState(() => _handRaised = next);
    try {
      await widget.api.raiseHand(widget.sessionId, raised: next);
    } catch (_) {
      setState(() => _handRaised = !next);
    }
  }

  Future<void> _sendReaction(String emoji) async {
    try {
      await widget.api.sendReaction(widget.sessionId, emoji);
      await _poll();
    } catch (_) {}
  }

  Future<void> _toggleRecording() async {
    try {
      if (_recording) {
        await widget.api.stopRecording(widget.sessionId);
      } else {
        await widget.api.startRecording(widget.sessionId);
      }
      setState(() => _recording = !_recording);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;

    if (_connecting) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator(color: cs.primary)),
      );
    }
    if (_connectError != null) {
      return Scaffold(
        backgroundColor: lsBg(context),
        appBar: lsAppBar(context, title: t.liveSessionTitle),
        body: ErrorStateWidget(title: t.couldNotJoinSession, retryLabel: t.retry, onRetry: _connect),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          // ---- Header ----
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.close_rounded, color: Colors.white), onPressed: () => Navigator.of(context).pop()),
              LsStatusChip(label: t.liveBadge, color: Colors.red, solid: true),
              if (_recording) ...[
                const SizedBox(width: 6),
                LsStatusChip(label: t.recordingBadge, color: Colors.redAccent, icon: Icons.fiber_manual_record_rounded),
              ],
              const Spacer(),
              if (widget.isHost) ...[
                IconButton(
                  icon: const Icon(Icons.grid_view_rounded, color: Colors.white),
                  tooltip: t.breakoutRoomsTitle,
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => BreakoutRoomsPanel(api: widget.api, sessionId: widget.sessionId),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.shield_outlined, color: Colors.white),
                  tooltip: t.moderationTitle,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => ModerationScreen(api: widget.api, sessionId: widget.sessionId, classroomId: widget.classroomId),
                  )),
                ),
                IconButton(
                  icon: Icon(_recording ? Icons.stop_circle_outlined : Icons.fiber_manual_record_outlined, color: Colors.white),
                  onPressed: _toggleRecording,
                ),
              ],
            ]),
          ),
          // ---- Video slot ----
          // Wire the `livekit_client` package here using the token/url
          // `widget.api.joinSession(widget.sessionId)` already returned
          // in `_connect()` above:
          //
          //   final room = Room();
          //   await room.connect(tokenResponse['url'], tokenResponse['token']);
          //   ...
          //   VideoTrackRenderer(track) // one per participant, laid out
          //                             // in a grid/spotlight in place
          //                             // of the placeholder Container below.
          //
          // Kept as a plain placeholder rather than a hard dependency
          // since the project's pinned `livekit_client` version wasn't
          // part of what was uploaded — its API shifts a little between
          // versions.
          Expanded(
            flex: 3,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(color: const Color(0xFF15121D), borderRadius: BorderRadius.circular(16)),
              child: Center(
                child: Icon(Icons.videocam_rounded, color: Colors.white24, size: 48),
              ),
            ),
          ),
          // ---- Poll banner ----
          if (_polls.any((p) => !p.isClosed))
            _PollBanner(poll: _polls.firstWhere((p) => !p.isClosed), api: widget.api, onVoted: _poll),
          // ---- Reaction bar ----
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(children: [
              for (final emoji in const ['heart', 'clap', 'laugh', 'wow'])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: InkWell(
                    onTap: () => _sendReaction(emoji),
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(20)),
                      child: Text('${_emojiFor(emoji)} ${_reactionCounts[emoji] ?? 0}', style: const TextStyle(color: Colors.white, fontSize: 12)),
                    ),
                  ),
                ),
              const Spacer(),
              InkWell(
                onTap: _toggleHand,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _handRaised ? cs.primary : Colors.white10,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.back_hand_rounded, size: 15, color: Colors.white),
                    const SizedBox(width: 6),
                    Text(t.raiseHandCta, style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ]),
                ),
              ),
            ]),
          ),
          // ---- Chat ----
          Expanded(
            flex: 4,
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              decoration: BoxDecoration(color: const Color(0xFF1A1625), borderRadius: BorderRadius.circular(16)),
              child: Column(children: [
                Expanded(
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(10),
                    itemCount: _chat.length,
                    itemBuilder: (context, i) {
                      final m = _chat[_chat.length - 1 - i];
                      if (m.isDeleted) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(text: '${m.senderName}: ', style: TextStyle(color: cs.primary, fontSize: 12.5, fontWeight: FontWeight.w700)),
                            TextSpan(text: m.message, style: const TextStyle(color: Colors.white, fontSize: 12.5)),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: _chatCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 13),
                        onSubmitted: (_) => _sendChat(),
                        decoration: InputDecoration(
                          hintText: t.typeMessageHint,
                          hintStyle: const TextStyle(color: Colors.white38),
                          filled: true,
                          fillColor: Colors.white10,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    IconButton(icon: Icon(Icons.send_rounded, color: cs.primary), onPressed: _sendChat),
                  ]),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  String _emojiFor(String key) => switch (key) {
        'heart' => '❤️',
        'clap' => '👏',
        'laugh' => '😂',
        'wow' => '😮',
        _ => '👍',
      };
}

class _PollBanner extends StatelessWidget {
  final LivePoll poll;
  final LiveClassApi api;
  final VoidCallback onVoted;
  const _PollBanner({required this.poll, required this.api, required this.onVoted});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(14)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(poll.question, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 8),
        ...poll.options.map((o) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: InkWell(
                onTap: poll.myVoteOptionId != null
                    ? null
                    : () async {
                        await api.votePoll(poll.id, o.id);
                        onVoted();
                      },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: poll.myVoteOptionId == o.id ? Colors.white24 : Colors.white10,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(children: [
                    Expanded(child: Text(o.text, style: const TextStyle(color: Colors.white, fontSize: 12.5))),
                    Text('${o.votes}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  ]),
                ),
              ),
            )),
      ]),
    );
  }
}
