import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../theme_service.dart';

// ============================================================
// LEARNSCROLL SHARED UI KIT
//
// Home, Assignments aur Test Series — teeno screens ek hi design language
// follow karti hain (`learnscroll_home_final.html`). Ye file wahi common
// pieces rakhti hai, taaki teen jagah teen alag-alag "card" definitions
// na banein aur baad me design tweak karna ek hi jagah ka kaam rahe.
//
// Yahan ek bhi hardcoded string nahi hai — har text caller se aata hai
// (l10n se). Aur ek bhi hardcoded color nahi — sab ColorScheme /
// AppThemeTokens se.
// ============================================================

/// HTML ke section paddings (`padding: 0 18px`).
const double kLsPad = 18;
const double kLsRadius = 18;

// ============================================================
// Task 11 — shared spacing/radius SCALE. Everything below existed as
// scattered magic numbers across this file (and screens that import it)
// before this pass — `BorderRadius.circular(20)` in one widget,
// `circular(24)` in the next, `circular(16)` in a third, with no
// indication whether any of them were meant to be the same value or
// three deliberately different ones. Naming them here doesn't change a
// single pixel on screen (every existing call site below is replaced
// with the token that already matched its old literal) — the point is
// that a future "make cards a bit more rounded app-wide" ask is now a
// one-line change in this file instead of a grep-and-hope across 190+
// screens.
//
// `kCardRadius` is `kLsRadius`'s own name for the "outer card corner"
// role specifically (post cards, notification tiles, profile stat
// cards) — same 18 value, kept as an alias rather than a new number so
// nothing that already relies on `kLsRadius` needs to change.
const double kCardRadius = kLsRadius;

/// Spacing scale — reach for one of these instead of a fresh literal
/// wherever a gap is "about page-padding-sized" rather than a genuinely
/// one-off value (icon-to-text gaps, tight internal padding, etc. are
/// fine left as their own small numbers — this scale is for the common,
/// reused sizes).
const double kSpaceXs = 4;
const double kSpaceSm = 8;
const double kSpaceMd = 12;
const double kSpaceLg = kLsPad; // 18 — same as the page padding, by name.
const double kSpaceXl = 24;

/// Radius scale — same reasoning as the spacing scale above. `kLsRadius`
/// (18, aliased as `kCardRadius`) stays the "big card" size; these fill
/// in the smaller/pill roles that were previously ad-hoc numbers.
const double kRadiusSm = 12; // small tappable rows (bottom-nav items, list tiles)
const double kRadiusMd = 16; // secondary cards/tiles smaller than a full LsCard
const double kRadiusChip = 20; // status chips, filter chips, small pills
const double kRadiusPill = 24; // full-height pill buttons (LsPrimaryButton/LsOutlineButton)

/// Heading/body/caption font helpers — the shared "text scale" Task 11
/// asks for. Before this, body/caption-ish text across screens used
/// whatever nearby literal felt right (an audit of this codebase turned
/// up fontSize values of 15, 13, 12, 11.5, 12.5, 11, 10.5, 9.5, 13.5 all
/// doing the same "small meta text" job in different files) — three
/// named sizes here doesn't force a rewrite of every screen, but gives
/// new/edited code one obvious place to reach for instead of adding yet
/// another one-off number.
class LsType {
  LsType._();

  /// Headings (HTML: `--font-head: Sora`) — section titles, card titles.
  static TextStyle head(BuildContext context, {double size = 14.5, Color? color, FontWeight weight = FontWeight.w700}) {
    return GoogleFonts.sora(
      fontSize: size,
      fontWeight: weight,
      color: color ?? Theme.of(context).colorScheme.onSurface,
    );
  }

  /// Body text (theme's default font, Inter) — normal readable copy.
  static TextStyle body(BuildContext context, {double size = 13, Color? color, FontWeight weight = FontWeight.w400}) {
    return TextStyle(
      fontSize: size,
      fontWeight: weight,
      color: color ?? Theme.of(context).colorScheme.onSurface,
    );
  }

  /// Caption/meta text — timestamps, counts, helper labels under a
  /// heading. Slightly bolder than body by default since captions are
  /// usually competing with body text right next to them for attention.
  static TextStyle caption(BuildContext context, {double size = 11, Color? color, FontWeight weight = FontWeight.w600}) {
    return TextStyle(
      fontSize: size,
      fontWeight: weight,
      color: color ?? Theme.of(context).colorScheme.onSurfaceVariant,
    );
  }
}

/// `.section-title` + optional trailing link (HTML `.section-head`).
class LsSectionHead extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;
  final EdgeInsetsGeometry padding;

  const LsSectionHead({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
    this.padding = const EdgeInsets.fromLTRB(kLsPad, 0, kLsPad, 10),
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: padding,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: LsType.head(context))),
        if (actionLabel != null && onAction != null)
          GestureDetector(
            onTap: onAction,
            child: Text(actionLabel!,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: cs.primary)),
          ),
      ]),
    );
  }
}

/// `.post-card` / `.live-card` wala surface — rounded, bordered, tinted.
class LsCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final bool tinted;
  final Color? borderColor;

  const LsCard({
    super.key,
    required this.child,
    this.margin,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.tinted = false,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final card = Container(
      margin: margin,
      decoration: BoxDecoration(
        color: tinted ? cs.surfaceVariant : cs.surface,
        border: Border.all(color: borderColor ?? cs.outlineVariant),
        borderRadius: BorderRadius.circular(kLsRadius),
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
    return card;
  }
}

/// Status pill — assignments ka submission status, test attempt status,
/// "LIVE" tag, "FREE"/coins badge; sab isi se bante hain.
class LsStatusChip extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;
  final bool solid;

  const LsStatusChip({
    super.key,
    required this.label,
    required this.color,
    this.icon,
    this.solid = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = solid ? color : color.withOpacity(isDark ? .22 : .12);
    final fg = solid ? _onColor(color) : color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: kSpaceSm, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(kRadiusChip)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 11, color: fg), const SizedBox(width: 4)],
        Text(label,
            style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, letterSpacing: .2, color: fg)),
      ]),
    );
  }

  static Color _onColor(Color bg) =>
      ThemeData.estimateBrightnessForColor(bg) == Brightness.dark ? Colors.white : const Color(0xFF1A1625);
}

/// Primary CTA — "Start test", "Submit", "Join".
class LsPrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final bool expanded;
  final Color? color;

  const LsPrimaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.expanded = true,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final bg = color ?? cs.primary;
    final disabled = onPressed == null || loading;
    final child = Row(
      mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (loading)
          SizedBox(
              width: 15,
              height: 15,
              child: CircularProgressIndicator(strokeWidth: 2, color: LsStatusChip._onColor(bg)))
        else if (icon != null)
          Icon(icon, size: 16, color: LsStatusChip._onColor(bg)),
        if (loading || icon != null) const SizedBox(width: 8),
        Flexible(
          child: Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: LsStatusChip._onColor(bg))),
        ),
      ],
    );

    return Semantics(
      button: true,
      enabled: !disabled,
      label: label,
      child: Opacity(
        opacity: disabled ? .55 : 1,
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(kRadiusPill),
          child: InkWell(
            onTap: disabled ? null : onPressed,
            borderRadius: BorderRadius.circular(kRadiusPill),
            child: Padding(padding: const EdgeInsets.symmetric(horizontal: kLsPad, vertical: 13), child: child),
          ),
        ),
      ),
    );
  }
}

/// Secondary / outline button.
class LsOutlineButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  const LsOutlineButton({super.key, required this.label, this.onPressed, this.icon});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Semantics(
      button: true,
      label: label,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(kRadiusPill),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(kRadiusPill),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(kRadiusPill),
              border: Border.all(color: cs.primary),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, size: 15, color: cs.primary), const SizedBox(width: 7)],
              Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: cs.primary)),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Filter chips row (Test Series: All / Free / Paid).
class LsFilterChips extends StatelessWidget {
  final List<String> labels;
  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final EdgeInsetsGeometry padding;

  const LsFilterChips({
    super.key,
    required this.labels,
    required this.selectedIndex,
    required this.onSelected,
    this.padding = const EdgeInsets.symmetric(horizontal: kLsPad),
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: padding,
        itemCount: labels.length,
        itemBuilder: (context, i) {
          final active = i == selectedIndex;
          return Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => onSelected(i),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: kSpaceSm),
                  decoration: BoxDecoration(
                    color: active ? cs.primary : cs.surface,
                    borderRadius: BorderRadius.circular(kRadiusChip),
                    border: Border.all(color: active ? cs.primary : cs.outlineVariant),
                  ),
                  child: Text(labels[i],
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: active ? cs.onPrimary : cs.onSurface)),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Label + value ki ek line (detail screens ke meta rows).
class LsMetaRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  const LsMetaRow({super.key, required this.icon, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Icon(icon, size: 15, color: cs.onSurfaceVariant),
        const SizedBox(width: 9),
        Expanded(child: Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant))),
        const SizedBox(width: 10),
        Text(value,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: valueColor ?? cs.onSurface)),
      ]),
    );
  }
}

/// Bade numbers dikhane wala tile (result screen ka score).
class LsScoreTile extends StatelessWidget {
  final String value;
  final String label;
  final Color color;
  const LsScoreTile({super.key, required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: kSpaceMd),
      decoration: BoxDecoration(
        color: color.withOpacity(isDark ? .18 : .10),
        borderRadius: BorderRadius.circular(kRadiusMd),
      ),
      child: Column(children: [
        Text(value, style: GoogleFonts.sora(fontSize: 20, fontWeight: FontWeight.w700, color: color)),
        const SizedBox(height: 3),
        Text(label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

/// Progress bar — attempt me "kitne answer ho gaye".
class LsProgressBar extends StatelessWidget {
  final double value; // 0..1
  final Color? color;
  final double height;
  const LsProgressBar({super.key, required this.value, this.color, this.height = 6});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: LinearProgressIndicator(
        value: value.clamp(0.0, 1.0),
        minHeight: height,
        backgroundColor: cs.surfaceVariant,
        color: color ?? cs.primary,
      ),
    );
  }
}

/// App bar jo home ke `.brand-row` jaisa hi flat dikhta hai (page bg,
/// koi elevation nahi) — dono naye modules isi ko use karte hain.
AppBar lsAppBar(BuildContext context, {required String title, List<Widget>? actions, Widget? leading}) {
  final cs = Theme.of(context).colorScheme;
  return AppBar(
    backgroundColor: lsBg(context),
    surfaceTintColor: Colors.transparent,
    elevation: 0,
    scrolledUnderElevation: 0,
    leading: leading,
    titleSpacing: leading == null ? kLsPad : 0,
    title: Text(title, style: LsType.head(context, size: 16)),
    iconTheme: IconThemeData(color: cs.onSurface),
    actions: actions,
  );
}

/// Snackbar helper — har screen me same shape.
void lsSnack(BuildContext context, String message, {bool error = false}) {
  final cs = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message, style: TextStyle(color: error ? cs.onError : null)),
      backgroundColor: error ? cs.error : null,
      behavior: SnackBarBehavior.floating,
    ));
}

/// Theme tokens ka chhota shortcut (import ek hi jagah se rahe).
AppThemeTokens lsTokens(BuildContext context) => AppThemeTokens.of(context);

/// Page background (HTML ka `--bg`).
///
/// `ColorScheme.background` jaan-boojh kar use NAHI hota — wo Flutter 3.18
/// me deprecate hua aur naye SDKs me hai hi nahi. Isliye bg hamesha
/// `AppThemeTokens` se aata hai; `Scaffold` bina `backgroundColor` diye
/// bhi theme ke `scaffoldBackgroundColor` se wahi color leta hai.
Color lsBg(BuildContext context) => AppThemeTokens.of(context).background;

// ============================================================
// SHARED BOTTOM NAV  [Task 6 — "ek type ka navigation"]
//
// Pehle teen alag bottom-nav implementations thi, teeno alag dikhte the:
//   - `home.dart`'s `_LsBottomNav`/`_LsNavItem` (private) — yehi asli
//     LearnScroll gradient look, ab yahan public bana diya.
//   - `tuitionclass/tuitionclass_home_shell.dart` — Flutter ka stock Material 3
//     `NavigationBar` (pill indicator, alag typography/spacing).
//   - `message/screens/app_bottom_nav.dart`'s `AppBottomNav` — stock
//     `BottomNavigationBar` (Material 2 style); iske apne comment me hi
//     likha tha "isn't a visual match for home.dart's actual bottom nav".
// Ab teeno isi ek widget se banti hain — icons/labels/tap-behaviour har
// jagah alag rehte hain (har shell ka apna nav-tree hai), sirf LOOK ek
// jaisa ho gaya hai.
// ============================================================

class LsBottomNavItemData {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  // 🔥 NAYA [Settings/Nav pass] — Chats tab pe unread-message count
  // dikhane ke liye (`.notif-badge` jaisa hi small pill, home.dart ke
  // `_lsIconButton`'s badge se same visual language). 0 ya kam = hidden.
  final int badge;
  const LsBottomNavItemData({
    required this.icon,
    required this.activeIcon,
    required this.label,
    this.badge = 0,
  });
}

class LsBottomNav extends StatelessWidget {
  final List<LsBottomNavItemData> items;

  /// Jis item ka icon/label highlight hona chahiye — `-1` agar koi bhi
  /// nahi (jaise home.dart me Campus/Classes/Chat tap hote hi ek naya
  /// screen push ho jaata hai, wo khud "current tab" nahi rehte).
  final int activeIndex;
  final ValueChanged<int> onTap;

  const LsBottomNav({super.key, required this.items, required this.activeIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        // HTML: linear-gradient(0deg, var(--bg) 60%, transparent)
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [lsBg(context), lsBg(context), lsBg(context).withOpacity(0)],
          stops: const [0, .6, 1],
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 12, 8, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              for (int i = 0; i < items.length; i++)
                _LsBottomNavItem(
                  icon: items[i].icon,
                  activeIcon: items[i].activeIcon,
                  label: items[i].label,
                  badge: items[i].badge,
                  active: i == activeIndex,
                  onTap: () => onTap(i),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LsBottomNavItem extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool active;
  final int badge;
  final VoidCallback onTap;
  const _LsBottomNavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.active,
    required this.onTap,
    this.badge = 0,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = active ? cs.primary : cs.onSurfaceVariant;
    return Expanded(
      child: Semantics(
        button: true,
        selected: active,
        label: label,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(kRadiusSm),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Stack(clipBehavior: Clip.none, children: [
                Icon(active ? activeIcon : icon, size: 24, color: color),
                // `.notif-badge` — home.dart ke `_lsIconButton` badge jaisa
                // hi look, bas chhota (bottom-nav icon 24px hai, 34px nahi).
                if (badge > 0)
                  Positioned(
                    top: -3,
                    right: -6,
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 13),
                      height: 13,
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: cs.secondary,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: lsBg(context), width: 1.5),
                      ),
                      child: Text(
                        badge > 9 ? '9+' : '$badge',
                        style: TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: cs.onSecondary, height: 1.2),
                      ),
                    ),
                  ),
              ]),
              const SizedBox(height: 4),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600, color: color),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
