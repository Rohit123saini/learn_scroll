// message/screens/conversations_screen.dart
//
// 🎨 REDESIGN — sab logic/state/API calls bilkul same hain (kuch bhi tod
// nahi hai), sirf visuals professional/polished bana diye hain — rounded
// search pill, better avatar treatment, cleaner unread badges, nicer empty
// states, aur ab wahi bottom nav bar bhi hai jo HomeScreen me hai — same
// 5 tabs, same order (Home / Campus / Classes / Chat / Profile) — dekho
// widgets/app_bottom_nav.dart.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../models/message_models.dart';
import '../services/message_api_service.dart';
import '../services/message_cache_service.dart';
import '../services/inbox_socket_service.dart';
import 'chat_screen.dart';
import 'create_group_screen.dart';
import 'study_groups_discovery_screen.dart'; // 🔥 NAYA (Task G14) — Study Groups discovery entry point
import '../../widgets/app_bottom_nav.dart'; // 🔥 FIX [Settings/Nav pass] — shared widget, home.dart ka exact mirror
import '../../widgets/skeletons.dart'; // LsListSkeleton — cold-start loading row skeleton (Task G16)
import 'message_search_screen.dart'; // 🔥 NAYA (Phase 4, §2.1/§4.2) — global message search
import 'focus_mode_screen.dart'; // 🔥 NAYA (Feature 12) — Smart DND / Focus Mode setup screen
import 'message_requests_screen.dart'; // 🔥 NAYA (M1-FE) — Message requests folder
import '../widgets/notes_bar.dart'; // 🔥 NAYA (M2-FE) — Notes row (Instagram-style status)

import '../../theme_service.dart'; // 🎨 THEME FIX — AppThemeTokens (home.dart jaisa hi shared design system)

// 🎨 THEME FIX — pehle ye sab hardcoded `const Color(...)` the (navy header,
// off-white bg, pink accent, amber banner) — kisi bhi theme mode me same hi
// rehte, isliye dark mode me bhi safed background aata tha. Ab sab
// `Theme.of(context)`/`AppThemeTokens.of(context)` se aate hain, home.dart
// jaisa hi (light/dark dono me sahi contrast).

class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({super.key});
  @override
  State<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  // 🎨 THEME FIX — home.dart jaisa hi shared design-system se colors.
  // `_navy` ab literally navy nahi — AppBar/header ka brand-primary color
  // hai (light me #5B3DF6, dark me #8B7CFF), taaki header dark mode me
  // bhi sahi dikhe. `_accent` = coral/accent token (unread badges), `_warn`
  // = amber-jaisa warning token (Focus Mode banner).
  Color get _navy => Theme.of(context).colorScheme.primary;
  Color get _onNavy => Theme.of(context).colorScheme.onPrimary;
  Color get _accent => Theme.of(context).colorScheme.secondary;
  Color get _warn => AppThemeTokens.of(context).warning;
  Color get _muted => Theme.of(context).colorScheme.onSurfaceVariant;
  Color get _border => Theme.of(context).colorScheme.outlineVariant;
  Color get _surface => Theme.of(context).colorScheme.surface;
  Color get _ink => Theme.of(context).colorScheme.onSurface;
  Color get _errorColor => Theme.of(context).colorScheme.error;

  List<ConversationModel> _conversations = [];
  bool _isLoading = true;
  String? _error;

  final _searchController = TextEditingController();
  final _searchFocusNode = FocusNode();
  Timer? _debounce;
  List<Map<String, dynamic>> _searchResults = [];
  bool _isSearching = false;
  String? _searchError;
  bool _isOpeningChat = false;
  bool _isSearchExpanded = false;

  StreamSubscription? _inboxSub;

  // 🔥 NAYA (M2-FE) — Notes row; pull-to-refresh par isko bhi refresh karte hain.
  final GlobalKey<NotesBarState> _notesKey = GlobalKey<NotesBarState>();

  // 🔥 NAYA — Long-press select mode: WhatsApp jaisa. Long-press se
  // select mode on hota hai (jis chat pe long-press hua wo select ho
  // jaati hai), fir tap se aur chats select/deselect kar sakte ho.
  // AppBar tab "N selected" dikhata hai delete/pin/rename actions ke
  // saath.
  bool _isSelectMode = false;
  final Set<String> _selectedIds = {};

  // 🔥 NAYA — Pin aur custom label ke liye local overrides. Jab tak
  // `ConversationModel` me ye fields add nahi ho jaate (backend already
  // support karta hai — `is_pinned` field + `.../settings/` aur
  // `.../label/` endpoints), UI turant reflect ho isliye yahi maintain
  // kar rahe hain, keyed by conversation.id.
  final Map<String, bool> _pinnedOverride = {};
  final Map<String, String> _labelOverride = {};

  // 🔥 NAYA (Feature 12) — abhi Focus Mode active hai ya nahi, aur kab
  // tak. Null = load nahi hua abhi tak ya koi active session nahi.
  FocusSessionStatus? _focusStatus;
  Timer? _focusTicker; // banner ka countdown live update karne ke liye

  @override
  void initState() {
    super.initState();
    _loadFromCacheThenNetwork();
    InboxSocketService.instance.connect();
    _inboxSub = InboxSocketService.instance.events.listen(_onInboxUpdate);
    _loadFocusStatus(); // 🔥 NAYA
    InboxSocketService.instance.refreshRequestCount(); // 🔥 NAYA (M1-FE) — "Message requests (N)" row
  }

  // 🔥 NAYA (M1-FE) — requests folder kholo; wapas aane par chat list aur
  // count dono refresh (accept hui chat ab inbox me aani chahiye).
  Future<void> _openMessageRequests() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const MessageRequestsScreen()),
    );
    if (!mounted) return;
    _loadConversations(silent: true);
    InboxSocketService.instance.refreshRequestCount();
  }

  // 🔥 NAYA (M1-FE) — chat list ke upar "Message requests (N)" row. N == 0
  // ho to poori row gayab. Count `InboxSocketService` se live aata hai
  // (`message_request` / `message_request_resolved` socket events).
  Widget _buildRequestsRow() {
    return ValueListenableBuilder<int>(
      valueListenable: InboxSocketService.instance.pendingRequestCount,
      builder: (context, count, _) {
        if (count <= 0) return const SizedBox.shrink();
        return InkWell(
          onTap: _openMessageRequests,
          child: Container(
            decoration: BoxDecoration(
              color: _surface,
              border: Border(bottom: BorderSide(color: _border)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(color: _navy.withOpacity(0.08), shape: BoxShape.circle),
                child: Icon(Icons.mark_chat_unread_outlined, color: _navy, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  'Message requests ($count)',
                  style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600, color: _ink),
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: _muted),
            ]),
          ),
        );
      },
    );
  }

  // 🔥 NAYA (Feature 12) — screen open hote hi current focus-status pata
  // karo (agar app kill/restart hua ho to bhi banner sahi state me aaye).
  Future<void> _loadFocusStatus() async {
    try {
      final status = await MessageApiService.getFocusStatus();
      if (!mounted) return;
      setState(() => _focusStatus = status);
      _restartFocusTicker();
    } catch (_) {
      // network fail ho to bas banner nahi dikhega — chat list load hona
      // is par depend nahi karta, isliye silently ignore.
    }
  }

  void _restartFocusTicker() {
    _focusTicker?.cancel();
    if (_focusStatus == null || !_focusStatus!.active) return;
    _focusTicker = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      if (_focusStatus!.endsAt.isBefore(DateTime.now())) {
        setState(() => _focusStatus = null);
        _focusTicker?.cancel();
      } else {
        setState(() {}); // countdown text refresh
      }
    });
  }

  Future<void> _openFocusModeScreen() async {
    final result = await Navigator.push<FocusSessionStatus?>(
      context,
      MaterialPageRoute(builder: (_) => FocusModeScreen(current: _focusStatus)),
    );
    // FocusModeScreen apna khud ka start/stop API call karke result
    // wapas bhejti hai — yahan sirf local state refresh karna hai.
    if (!mounted) return;
    setState(() => _focusStatus = result);
    _restartFocusTicker();
  }

  void _onInboxUpdate(Map<String, dynamic> event) {
    // 🔥 NAYA — mutual-follow se auto-create hua (abhi tak zero-message)
    // conversation (backend: `message.services.get_or_create_conversation`,
    // `user_profile/signals.py` se trigger hota hai). Koi `last_message_*`
    // is event me nahi hota (ye `inbox_update` jaisa message-around-event
    // nahi hai) — list me abhi present na ho to seedha silent refresh kar
    // do, taaki naya conversation (empty-state "Start the conversation"
    // placeholder ke saath, see `_lastMessagePreview()`) turant dikhe.
    if (event['type'] == 'conversation_created') {
      final conversationId = event['conversation_id']?.toString();
      if (conversationId != null && !_conversations.any((c) => c.id == conversationId)) {
        _loadConversations(silent: true);
      }
      return;
    }

    if (event['type'] != 'inbox_update') return;
    final conversationId = event['conversation_id']?.toString();
    if (conversationId == null) return;

    final index = _conversations.indexWhere((c) => c.id == conversationId);
    if (index == -1) {
      _loadConversations(silent: true);
      return;
    }

    final createdAtRaw = event['created_at']?.toString();
    final createdAt = createdAtRaw != null ? DateTime.tryParse(createdAtRaw) : null;

    setState(() {
      final convo = _conversations[index];
      convo.lastMessageText = event['last_message_text']?.toString();
      convo.lastMessageType = event['last_message_type']?.toString();
      convo.lastMessageAt = createdAt ?? convo.lastMessageAt;
      convo.unreadCount = convo.unreadCount + 1;
      _conversations.removeAt(index);
      _conversations.insert(0, convo);
    });

    MessageCacheService.saveConversations(_conversations);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    _searchFocusNode.dispose();
    _inboxSub?.cancel();
    _focusTicker?.cancel(); // 🔥 NAYA
    super.dispose();
  }

  void _toggleSearch() {
    setState(() => _isSearchExpanded = !_isSearchExpanded);
    if (_isSearchExpanded) {
      Future.delayed(const Duration(milliseconds: 50), () {
        if (mounted && _isSearchExpanded) _searchFocusNode.requestFocus();
      });
    } else {
      _searchFocusNode.unfocus();
      _searchController.clear();
      setState(() => _searchResults = []);
    }
  }

  void _onSearchChanged(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => _runSearch(query));
    setState(() => _searchError = null);
  }

  Future<void> _runSearch(String query) async {
    if (query.trim().isEmpty) {
      setState(() => _searchResults = []);
      return;
    }
    setState(() => _isSearching = true);
    try {
      final results = await MessageApiService.searchUsers(query);
      if (!mounted) return;
      setState(() {
        _searchResults = results;
        _isSearching = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSearching = false;
        _searchError = e.toString();
      });
    }
  }

  String _displayName(Map<String, dynamic> user) {
    final first = (user['first_name'] ?? '').toString().trim();
    final last = (user['last_name'] ?? '').toString().trim();
    final full = [first, last].where((s) => s.isNotEmpty).join(' ');
    if (full.isNotEmpty) return full;
    final username = (user['username'] ?? '').toString().trim();
    return username.isNotEmpty ? username : 'User';
  }

  Future<void> _openUserChat(Map<String, dynamic> user) async {
    final userId = user['id']?.toString();
    if (userId == null || _isOpeningChat) return;

    setState(() => _isOpeningChat = true);
    try {
      final convo = await MessageApiService.startPrivateChat(userId);
      if (!mounted) return;
      _searchController.clear();
      setState(() {
        _searchResults = [];
        _isOpeningChat = false;
        _isSearchExpanded = false;
      });
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ChatScreen(conversation: convo)),
      );
      _loadConversations(silent: true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isOpeningChat = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Chat shuru nahi ho payi: $e")),
      );
    }
  }

  Future<void> _loadFromCacheThenNetwork() async {
    final cached = await MessageCacheService.getCachedConversations();
    if (cached.isNotEmpty && mounted) {
      setState(() {
        _conversations = cached;
        _isLoading = false;
      });
    }
    _loadConversations(silent: cached.isNotEmpty);
  }

  Future<void> _loadConversations({bool silent = false}) async {
    if (!silent) setState(() { _isLoading = true; _error = null; });
    try {
      final data = await MessageApiService.getConversations();
      if (mounted) setState(() { _conversations = data; _isLoading = false; });
      MessageCacheService.saveConversations(data);
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          if (_conversations.isEmpty) _error = e.toString();
        });
      }
    }
  }

  void _openChat(ConversationModel convo) async {
    if (_isSelectMode) {
      _toggleSelect(convo.id);
      return;
    }
    setState(() => convo.unreadCount = 0);
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ChatScreen(conversation: convo)),
    );
    _loadConversations(silent: true);
  }

  bool _isPinned(ConversationModel c) => _pinnedOverride[c.id] ?? false;

  String _displayLabel(ConversationModel c) =>
      _labelOverride[c.id] ?? c.displayTitle;

  // 🔥 NAYA (Feature 11) — teacher/staff ka unread announcement hai to
  // true. `hasUnreadAnnouncement` field `ConversationModel` me add karna
  // hoga (backend `is_announcement` flag se derive hota hai — dekho
  // message_models_patch.md).
  bool _hasUnreadAnnouncement(ConversationModel c) =>
      c.hasUnreadAnnouncement && c.unreadCount > 0;

  List<ConversationModel> _sortedConversations() {
    final list = List<ConversationModel>.from(_conversations);
    list.sort((a, b) {
      final pinnedA = _isPinned(a) ? 1 : 0;
      final pinnedB = _isPinned(b) ? 1 : 0;
      if (pinnedA != pinnedB) return pinnedB - pinnedA; // pinned sabse pehle

      // 🔥 NAYA — unread announcements pinned ke turant baad, normal
      // chit-chat se pehle. Slack ke automatic-pinned-channel jaisa feel.
      final annA = _hasUnreadAnnouncement(a) ? 1 : 0;
      final annB = _hasUnreadAnnouncement(b) ? 1 : 0;
      if (annA != annB) return annB - annA;

      final atA = a.lastMessageAt;
      final atB = b.lastMessageAt;
      if (atA == null && atB == null) return 0;
      if (atA == null) return 1;
      if (atB == null) return -1;
      return atB.compareTo(atA);
    });
    return list;
  }

  void _enterSelectMode(String conversationId) {
    setState(() {
      _isSelectMode = true;
      _selectedIds.add(conversationId);
    });
  }

  void _toggleSelect(String conversationId) {
    setState(() {
      if (_selectedIds.contains(conversationId)) {
        _selectedIds.remove(conversationId);
        if (_selectedIds.isEmpty) _isSelectMode = false;
      } else {
        _selectedIds.add(conversationId);
      }
    });
  }

  void _exitSelectMode() {
    setState(() {
      _isSelectMode = false;
      _selectedIds.clear();
    });
  }

  // 🔥 NAYA — 1: Selected chat(s) delete karna. Sirf apni taraf se hide
  // hoti hain (backend `bulk_delete` — dusre participant/group ki chat
  // waisi hi rehti hai).
  Future<void> _confirmDeleteSelected() async {
    final ids = _selectedIds.toList();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Chat delete karein?'),
        content: Text(
          ids.length == 1
              ? 'Ye chat delete ho jaayegi. Dusre participant ki chat waisi hi rahegi.'
              : '${ids.length} chats delete ho jaayengi. Dusre participants ki chat waisi hi rahegi.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Delete', style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await MessageApiService.bulkDeleteConversations(ids);
      if (!mounted) return;
      setState(() {
        _conversations.removeWhere((c) => ids.contains(c.id));
        for (final id in ids) {
          _pinnedOverride.remove(id);
          _labelOverride.remove(id);
        }
        _isSelectMode = false;
        _selectedIds.clear();
      });
      MessageCacheService.saveConversations(_conversations);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Delete fail: $e')),
      );
    }
  }

  // 🔥 NAYA — 2: Selected chat(s) ko pin/unpin karna (top pe rakhna). Agar
  // koi ek bhi selected chat already pinned nahi hai to sabko pin karo,
  // warna sabko unpin karo (WhatsApp jaisa toggle behaviour).
  Future<void> _togglePinSelected() async {
    final ids = _selectedIds.toList();
    final shouldPin = ids.any((id) => !(_pinnedOverride[id] ?? false));

    // Optimistic UI update.
    setState(() {
      for (final id in ids) {
        _pinnedOverride[id] = shouldPin;
      }
    });

    try {
      for (final id in ids) {
        await MessageApiService.updateSettings(id, isPinned: shouldPin);
      }
    } catch (e) {
      if (!mounted) return;
      // rollback on failure
      setState(() {
        for (final id in ids) {
          _pinnedOverride[id] = !shouldPin;
        }
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pin update fail: $e')),
      );
      return;
    }

    if (!mounted) return;
    setState(() {
      _isSelectMode = false;
      _selectedIds.clear();
    });
  }

  // 🔥 NAYA — 3: Chat ka label/nickname change karna. Sirf single chat
  // select hone par hi available hai.
  Future<void> _renameSelected() async {
    final id = _selectedIds.first;
    final convo = _conversations.firstWhere((c) => c.id == id);
    final controller = TextEditingController(text: _labelOverride[id] ?? '');

    final newLabel = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Chat ka naam badlein'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 100,
          decoration: InputDecoration(hintText: convo.displayTitle),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (newLabel == null) return;

    try {
      final saved = await MessageApiService.updateConversationLabel(id, newLabel);
      if (!mounted) return;
      setState(() {
        if (saved == null || saved.isEmpty) {
          _labelOverride.remove(id);
        } else {
          _labelOverride[id] = saved;
        }
        _isSelectMode = false;
        _selectedIds.clear();
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Naam save nahi hua: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 🎨 THEME FIX — was hardcoded `_kBg` (always off-white, even in dark
      // mode). Falls back to the theme's own scaffoldBackgroundColor now.
      appBar: _isSelectMode ? _buildSelectionAppBar() : _buildDefaultAppBar(),
      body: Column(
        children: [
          if (!_isSelectMode && _buildFocusBanner() != null) _buildFocusBanner()!, // 🔥 NAYA
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeInOut,
            child: _isSearchExpanded ? _buildSearchField() : const SizedBox(width: double.infinity),
          ),
          // 🔥 NAYA (M2-FE) — Notes row, inbox ke bilkul upar. `Visibility(maintainState)`
          // taaki select mode / search se wapas aane par dobara fetch na ho.
          Visibility(
            visible: !_isSelectMode && !(_isSearchExpanded && _searchController.text.trim().isNotEmpty),
            maintainState: true,
            child: NotesBar(key: _notesKey),
          ),
          // 🔥 NAYA (M1-FE) — select mode / user-search ke dauraan nahi dikhti
          if (!_isSelectMode && !(_isSearchExpanded && _searchController.text.trim().isNotEmpty))
            _buildRequestsRow(),
          Expanded(
            child: _isSearchExpanded && _searchController.text.trim().isNotEmpty
                ? _buildSearchResults()
                : RefreshIndicator(
                    color: _navy,
                    onRefresh: () {
                      _notesKey.currentState?.refresh(); // 🔥 NAYA (M2-FE) — fire-and-forget
                      return _loadConversations();
                    },
                    child: _buildBody(),
                  ),
          ),
        ],
      ),
      // 🔥 FIX [Settings/Nav pass] — `AppTab.chats` → `AppTab.chat`, aur
      // widget ab home.dart ke asli 5-tab nav ka exact mirror hai (dekho
      // widgets/app_bottom_nav.dart).
      bottomNavigationBar: const AppBottomNav(current: AppTab.chat),
    );
  }

  AppBar _buildDefaultAppBar() {
    return AppBar(
      backgroundColor: _navy,
      elevation: 0,
      title: Text(
        "Chats",
        style: TextStyle(color: _onNavy, fontWeight: FontWeight.w700, fontSize: 20),
      ),
      iconTheme: IconThemeData(color: _onNavy),
      actions: [
        IconButton(
          icon: Icon(_isSearchExpanded ? Icons.close : Icons.search_rounded, color: _onNavy),
          tooltip: _isSearchExpanded ? 'Close search' : 'Search people to start a chat',
          onPressed: _toggleSearch,
        ),
        // 🔥 NAYA (Phase 4, §1 #1, §2.1, §4.2) — ye "search users to start
        // a new chat" (upar wala icon) se ALAG hai — ye MESSAGE CONTENT
        // search hai, saari existing conversations ke andar (global
        // `search_all`). Alag icon isliye taaki dono confuse na ho.
        IconButton(
          icon: Icon(Icons.manage_search_rounded, color: _onNavy),
          tooltip: 'Search messages',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MessageSearchScreen()),
            );
          },
        ),
        IconButton(
          icon: Icon(Icons.group_add_rounded, color: _onNavy),
          tooltip: 'New group',
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CreateGroupScreen()),
            );
            _loadConversations(silent: true);
          },
        ),
        // 🔥 NAYA (Task G14) — Study Groups discovery entry point. Alag
        // icon rakha "New group" (upar wala, jo ad-hoc contacts se group
        // banata hai) se — ye PUBLIC groups browse/search/join karne ke
        // liye hai, apne existing contacts ke bahar bhi.
        IconButton(
          icon: Icon(Icons.travel_explore_rounded, color: _onNavy),
          tooltip: 'Discover study groups',
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StudyGroupsDiscoveryScreen()),
            );
            _loadConversations(silent: true);
          },
        ),
        // 🔥 NAYA (Feature 12) — Focus Mode entry point. Active hote hi
        // icon filled + accent color me badal jaata hai taaki ek nazar
        // me pata chale "DND on hai" bina banner padhe bhi.
        IconButton(
          icon: Icon(
            (_focusStatus?.active ?? false) ? Icons.bolt_rounded : Icons.bolt_outlined,
            color: (_focusStatus?.active ?? false) ? _warn : _onNavy,
          ),
          tooltip: 'Focus mode',
          onPressed: _openFocusModeScreen,
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // 🔥 NAYA (Feature 12) — persistent banner jab Focus Mode active hai.
  // Conversations list ke top pe rehta hai (search bar ke neeche), tap
  // karke seedha Focus Mode screen khulti hai (extend/end karne ke liye).
  Widget? _buildFocusBanner() {
    final status = _focusStatus;
    if (status == null || !status.active) return null;
    final remaining = status.endsAt.difference(DateTime.now());
    if (remaining.isNegative) return null;
    final h = remaining.inHours;
    final m = remaining.inMinutes.remainder(60);
    final remainingText = h > 0 ? '${h}h ${m}m left' : '${m}m left';
    final onlyTeachers = status.exceptionRule == 'teachers_only';

    return InkWell(
      onTap: _openFocusModeScreen,
      child: Container(
        width: double.infinity,
        color: _warn.withOpacity(0.12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(children: [
          Icon(Icons.bolt_rounded, size: 18, color: _warn),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              onlyTeachers
                  ? 'Focus mode: $remainingText · only teacher pings'
                  : 'Focus mode: $remainingText · everything muted',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: _warn),
            ),
          ),
          Icon(Icons.chevron_right_rounded, size: 18, color: _warn),
        ]),
      ),
    );
  }

  // 🔥 NAYA — Selection mode ka AppBar: "N selected" + Pin/Unpin, Rename
  // (sirf 1 select ho to) aur Delete actions.
  AppBar _buildSelectionAppBar() {
    final count = _selectedIds.length;
    final allPinned = _selectedIds.isNotEmpty &&
        _selectedIds.every((id) => _pinnedOverride[id] ?? false);
    return AppBar(
      backgroundColor: _navy,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.close_rounded, color: _onNavy),
        tooltip: 'Cancel',
        onPressed: _exitSelectMode,
      ),
      title: Text(
        '$count selected',
        style: TextStyle(color: _onNavy, fontWeight: FontWeight.w700, fontSize: 18),
      ),
      iconTheme: IconThemeData(color: _onNavy),
      actions: [
        if (count == 1)
          IconButton(
            icon: Icon(Icons.edit_rounded, color: _onNavy),
            tooltip: 'Rename',
            onPressed: _renameSelected,
          ),
        IconButton(
          icon: Icon(allPinned ? Icons.push_pin : Icons.push_pin_outlined, color: _onNavy),
          tooltip: allPinned ? 'Unpin' : 'Pin',
          onPressed: count == 0 ? null : _togglePinSelected,
        ),
        IconButton(
          icon: Icon(Icons.delete_outline_rounded, color: _onNavy),
          tooltip: 'Delete',
          onPressed: count == 0 ? null : _confirmDeleteSelected,
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildSearchField() {
    return Container(
      color: _navy,
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Container(
        decoration: BoxDecoration(
          color: _surface,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 8, offset: const Offset(0, 3)),
          ],
        ),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          onChanged: _onSearchChanged,
          decoration: InputDecoration(
            hintText: "Search users to chat",
            hintStyle: TextStyle(color: _muted, fontSize: 14),
            prefixIcon: Icon(Icons.search_rounded, color: _muted),
            suffixIcon: _isSearching
                ? Padding(
                    padding: const EdgeInsets.all(14),
                    child: SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: _navy),
                    ),
                  )
                : (_searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.close_rounded, color: _muted),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchResults = []);
                        },
                      )
                    : null),
            filled: true,
            fillColor: Colors.transparent,
            contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    if (_searchError != null) {
      return Center(
        child: Text("Search fail: $_searchError", style: TextStyle(color: _errorColor)),
      );
    }
    if (_searchResults.isEmpty && !_isSearching) {
      return _emptyState(icon: Icons.person_search_rounded, text: "Koi user nahi mila");
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: _searchResults.length,
      itemBuilder: (context, index) {
        final user = _searchResults[index];
        return ListTile(
          onTap: _isOpeningChat ? null : () => _openUserChat(user),
          tileColor: _surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: _avatar(context, user['avatar']?.toString(), radius: 24, isGroup: false),
          title: Text(_displayName(user), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
          subtitle: Text('@${user['username'] ?? ''}', style: TextStyle(fontSize: 12, color: _muted)),
          trailing: _isOpeningChat
              ? SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _navy),
                )
              : Icon(Icons.chevron_right_rounded, color: _muted),
        );
      },
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      // TASK G16 — this only ever renders on a true cold start (no local
      // cache yet: see _loadFromCacheThenNetwork, which already flips
      // _isLoading false the instant cached rows exist). It used to be a
      // bare full-screen spinner even though every other list screen in
      // the app had already moved to skeleton rows — swapped for the
      // generic row skeleton so a brand-new device doesn't see a
      // noticeably jankier first-open than everyone else.
      return const LsListSkeleton(count: 7, sidePad: 16, trailingChip: true);
    }
    if (_error != null) {
      return ListView(children: [
        const SizedBox(height: 100),
        Icon(Icons.wifi_off_rounded, size: 52, color: _muted),
        const SizedBox(height: 12),
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text("Failed to load: $_error",
                textAlign: TextAlign.center, style: TextStyle(color: _muted)),
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: () => _loadConversations(),
            child: Text("Retry", style: TextStyle(color: _navy, fontWeight: FontWeight.bold)),
          ),
        ),
      ]);
    }
    if (_conversations.isEmpty) {
      return ListView(children: [
        const SizedBox(height: 130),
        _emptyState(icon: Icons.chat_bubble_outline_rounded, text: "No conversations yet"),
        const SizedBox(height: 6),
        Center(
          child: Text("Tap search above to start chatting",
              style: TextStyle(color: _muted, fontSize: 12)),
        ),
      ]);
    }
    final sorted = _sortedConversations();
    return ListView.separated(
      padding: const EdgeInsets.only(top: 4),
      itemCount: sorted.length,
      separatorBuilder: (_, __) => Divider(height: 1, indent: 84, color: _border),
      itemBuilder: (context, index) {
        final convo = sorted[index];
        return _ConversationTile(
          conversation: convo,
          displayTitle: _displayLabel(convo),
          isPinned: _isPinned(convo),
          isAnnouncement: _hasUnreadAnnouncement(convo), // 🔥 NAYA
          isSelectMode: _isSelectMode,
          isSelected: _selectedIds.contains(convo.id),
          onTap: () => _openChat(convo),
          onLongPress: () => _enterSelectMode(convo.id),
        );
      },
    );
  }

  Widget _emptyState({required IconData icon, required String text}) {
    return Column(children: [
      Container(
        width: 88, height: 88,
        decoration: BoxDecoration(color: _navy.withOpacity(0.06), shape: BoxShape.circle),
        child: Icon(icon, size: 40, color: _navy.withOpacity(0.5)),
      ),
      const SizedBox(height: 14),
      Text(text, style: TextStyle(color: _muted, fontSize: 14, fontWeight: FontWeight.w500)),
    ]);
  }
}

Widget _avatar(BuildContext context, String? photo, {required double radius, required bool isGroup}) {
  final hasPhoto = photo != null && photo.isNotEmpty;
  final cs = Theme.of(context).colorScheme;
  return Container(
    padding: const EdgeInsets.all(2),
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      border: Border.all(color: cs.outlineVariant, width: 1),
    ),
    child: CircleAvatar(
      radius: radius,
      backgroundColor: AppThemeTokens.of(context).surface2,
      backgroundImage: hasPhoto ? CachedNetworkImageProvider(photo) : null,
      child: !hasPhoto
          ? Icon(isGroup ? Icons.group_rounded : Icons.person_rounded, color: cs.onSurfaceVariant)
          : null,
    ),
  );
}

class _ConversationTile extends StatelessWidget {
  final ConversationModel conversation;
  final String displayTitle;
  final bool isPinned;
  final bool isAnnouncement; // 🔥 NAYA (Feature 11)
  final bool isSelectMode;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _ConversationTile({
    required this.conversation,
    required this.displayTitle,
    required this.isPinned,
    this.isAnnouncement = false,
    required this.isSelectMode,
    required this.isSelected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final hasUnread = conversation.unreadCount > 0;
    final cs = Theme.of(context).colorScheme;
    final tokens = AppThemeTokens.of(context);
    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        color: isSelected
            ? tokens.coral.withOpacity(0.08)
            : (isAnnouncement ? tokens.warning.withOpacity(0.07) : cs.surface), // 🔥 NAYA — Slack-jaisi pinned-lane tint
        decoration: isAnnouncement && !isSelected
            ? BoxDecoration(border: Border(left: BorderSide(color: tokens.warning, width: 3)))
            : null,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (isSelectMode)
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: Icon(
                  isSelected ? Icons.check_circle_rounded : Icons.circle_outlined,
                  color: isSelected ? tokens.coral : cs.onSurfaceVariant,
                  size: 24,
                ),
              )
            else
              _avatar(context, conversation.displayPhoto, radius: 27, isGroup: conversation.isGroup),
            if (isSelectMode) const SizedBox(width: 2),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (isPinned) ...[
                        Icon(Icons.push_pin, size: 13, color: cs.onSurfaceVariant),
                        const SizedBox(width: 4),
                      ],
                      if (isAnnouncement) ...[
                        // 🔥 NAYA (Feature 11) — teacher/staff badge
                        Icon(Icons.campaign_rounded, size: 14, color: tokens.warning),
                        const SizedBox(width: 4),
                      ],
                      Expanded(
                        child: Text(
                          displayTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: hasUnread ? FontWeight.bold : FontWeight.w600,
                            fontSize: 15.5,
                            color: cs.onSurface,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  // 🔥 NAYA (Phase 3, §7.10/§4.2) — agar is conversation ka
                  // server-saved draft hai (`mySettings.draftText`), last
                  // message ki jagah "Draft: <text>" dikhao (WhatsApp jaisa)
                  // — data already `ConversationListSerializer.my_settings`
                  // se aata hai, koi extra call nahi chahiye.
                  Builder(builder: (context) {
                    final draft = conversation.mySettings.draftText;
                    if (draft != null && draft.trim().isNotEmpty) {
                      return RichText(
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        text: TextSpan(
                          style: TextStyle(fontSize: 13.5, color: cs.onSurfaceVariant),
                          children: [
                            TextSpan(
                              text: "Draft: ",
                              style: TextStyle(color: cs.error, fontStyle: FontStyle.italic, fontWeight: FontWeight.w600),
                            ),
                            TextSpan(text: draft.trim(), style: const TextStyle(fontStyle: FontStyle.italic)),
                          ],
                        ),
                      );
                    }
                    return Text(
                      _lastMessagePreview(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: hasUnread ? cs.onSurface : cs.onSurfaceVariant,
                        fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                        fontSize: 13.5,
                      ),
                    );
                  }),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (conversation.lastMessageAt != null)
                  Text(
                    timeago.format(conversation.lastMessageAt!, locale: 'en_short'),
                    style: TextStyle(
                      fontSize: 11.5,
                      color: hasUnread ? tokens.coral : cs.onSurfaceVariant,
                      fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                const SizedBox(height: 8),
                if (hasUnread)
                  Container(
                    constraints: const BoxConstraints(minWidth: 20),
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: tokens.coral, borderRadius: BorderRadius.circular(12)),
                    child: Text(
                      conversation.unreadCount > 99 ? '99+' : conversation.unreadCount.toString(),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: cs.onSecondary, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  )
                else
                  const SizedBox(height: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _lastMessagePreview() {
    if (conversation.lastMessageText == null || conversation.lastMessageText!.isEmpty) {
      switch (conversation.lastMessageType) {
        case 'image': return '📷 Photo';
        case 'video': return '🎥 Video';
        case 'audio': return '🎵 Audio';
        case 'file': return '📄 File';
        case 'presentation': return '📊 Presentation';
        case 'location': return '📍 Location';
        // 🔥 NAYA — zero-message conversation (mutual-follow se
        // auto-create hua, ya `start_private` se banaya gaya, koi bhi
        // message bheje bina) ke liye blank/"No messages yet" ki jagah
        // "say hi" jaisa nudge — jaisa Instagram naye mutual-follow pe
        // dikhata hai.
        default: return 'Say hi 👋 — start the conversation';
      }
    }
    return conversation.lastMessageText!;
  }
}