// message/screens/focus_session_history_screen.dart
//
// 🔧 NEW — Feature 12 gap fix: pehle sirf CURRENT active focus session
// dikhta tha (focus_mode_screen.dart) — past sessions (kitni der padha,
// kitni baar use kiya, kitni baar early end kiya) dekhne ka koi tarika
// nahi tha. Backend me data already tha (FocusSession rows kabhi delete
// nahi hoti), sirf ise dikhane wala screen + endpoint missing tha
// (GET /message/focus-session/history/, see views_focus.py).
//
// ⚠️ WIRING NOTE: `focus_mode_screen.dart` upload nahi hui thi, isliye
// yahan directly edit nahi kar saka. Wahan entry point add karne ke
// liye AppBar me ek action button:
//
//   AppBar(
//     title: const Text('Focus Mode'),
//     actions: [
//       IconButton(
//         icon: const Icon(Icons.history),
//         tooltip: 'History',
//         onPressed: () => Navigator.push(context, MaterialPageRoute(
//           builder: (_) => const FocusSessionHistoryScreen())),
//       ),
//     ],
//   )
//
// ⚠️ Same as manage_parent_access_screen.dart: placeholder `_baseUrl` +
// `_authHeaders()` below — plug in the app's real HTTP client/base URL.

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../services/auth_service.dart';
import '../../utils/api.dart';
import '../../theme_service.dart'; // 🎨 THEME FIX — AppThemeTokens

class FocusSessionHistoryEntry {
  final String id;
  final DateTime startsAt;
  final DateTime endsAt;
  final String exceptionRule; // 'teachers_only' | 'nobody'
  final bool endedEarly;
  final int durationMinutes;

  FocusSessionHistoryEntry({
    required this.id,
    required this.startsAt,
    required this.endsAt,
    required this.exceptionRule,
    required this.endedEarly,
    required this.durationMinutes,
  });

  factory FocusSessionHistoryEntry.fromJson(Map<String, dynamic> json) => FocusSessionHistoryEntry(
        id: json['id'],
        startsAt: DateTime.parse(json['starts_at']).toLocal(),
        endsAt: DateTime.parse(json['ends_at']).toLocal(),
        exceptionRule: json['exception_rule'] ?? 'teachers_only',
        endedEarly: json['ended_early'] == true,
        durationMinutes: (json['duration_minutes'] as num?)?.toInt() ?? 0,
      );
}

class FocusSessionHistoryScreen extends StatefulWidget {
  const FocusSessionHistoryScreen({super.key});

  @override
  State<FocusSessionHistoryScreen> createState() => _FocusSessionHistoryScreenState();
}

class _FocusSessionHistoryScreenState extends State<FocusSessionHistoryScreen> {
  // 🔧 FIX — same as `manage_parent_access_screen.dart`: was a dead
  // placeholder host, now `message_api_service.dart`'s real `Api.baseUrl`.
  static String get _baseUrl => "${Api.baseUrl}/message";

  List<FocusSessionHistoryEntry> _sessions = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  // 🔧 FIX — was reading raw `access_token` with no expiry check (same
  // bug as `main.dart`/`message_api_service.dart` had before). Now uses
  // `AuthService.getValidToken()`, same as everywhere else in the app.
  Future<Map<String, String>> _authHeaders() async {
    final token = await AuthService.getValidToken() ?? '';
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<void> _fetchHistory() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/focus-session/history/?limit=50'),
        headers: await _authHeaders(),
      );
      if (res.statusCode != 200) throw Exception('Load failed');
      final data = jsonDecode(res.body);
      final list = (data['sessions'] as List? ?? []);
      setState(() => _sessions = list.map((e) => FocusSessionHistoryEntry.fromJson(e)).toList());
    } catch (_) {
      setState(() => _error = 'History load nahi ho paayi.');
    } finally {
      setState(() => _loading = false);
    }
  }

  String _durationLabel(int minutes) {
    if (minutes < 60) return '$minutes min';
    final hours = minutes ~/ 60;
    final rem = minutes % 60;
    return rem == 0 ? '${hours}h' : '${hours}h ${rem}m';
  }

  String _dateLabel(DateTime dt) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${dt.day} ${months[dt.month - 1]}, ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tokens = AppThemeTokens.of(context);
    return Scaffold(
      // 🎨 THEME FIX — was hardcoded dark-only (0xFF0F0F11 + white text),
      // never adapted in light mode. Now uses theme bg/surface/ink.
      appBar: AppBar(
        title: const Text('Focus Mode — History'),
      ),
      body: RefreshIndicator(
        onRefresh: _fetchHistory,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Text(_error!, style: TextStyle(color: cs.error)))
                : _sessions.isEmpty
                    ? ListView(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 80),
                            child: Center(
                              child: Text(
                                'Abhi tak koi focus session nahi hui.',
                                style: TextStyle(color: cs.onSurfaceVariant),
                              ),
                            ),
                          ),
                        ],
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _sessions.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          final s = _sessions[i];
                          return Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: tokens.surface2,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  s.endedEarly ? Icons.stop_circle_outlined : Icons.check_circle_outline,
                                  color: s.endedEarly ? tokens.warning : tokens.success,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        _dateLabel(s.startsAt),
                                        style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w600),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        '${_durationLabel(s.durationMinutes)} · '
                                        '${s.exceptionRule == 'nobody' ? 'Full silence' : 'Teachers only'}'
                                        '${s.endedEarly ? ' · ended early' : ''}',
                                        style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
      ),
    );
  }
}