// lib/tuitionclass/screens/notice_board_screen.dart
//
// Screen §13 — Notice Board. GET/POST notices/, POST notices/{id}/pin/,
// DELETE notices/{id}/. Priority-coded cards (low/normal/urgent), pinned
// notices sorted to the top. Teacher/staff post; everyone with classroom
// access reads.
//
// Restyled onto the shared TuitionClass design system (tuitionclass_theme.dart)
// so it matches Certificates/Holidays/Materials instead of falling back to
// plain Material defaults. Logic/API calls unchanged.

import 'package:flutter/material.dart';

import '../../l10n/app_localizations.dart';
import '../../testseries/screens/test_series_detail_screen.dart';
import '../models/tuitionclass_models.dart';
import '../services/tuitionclass_api_service.dart';
import '../theme/tuitionclass_theme.dart';

Color _priorityColor(String priority) {
  switch (priority) {
    case NoticePriority.urgent:
      return TuitionClassColors.danger;
    case NoticePriority.low:
      return Colors.grey.shade600;
    default:
      return TuitionClassColors.navy;
  }
}

class NoticeBoardScreen extends StatefulWidget {
  final int classroomId;
  final bool canManage; // teacher/co-teacher/moderator

  const NoticeBoardScreen({super.key, required this.classroomId, required this.canManage});

  @override
  State<NoticeBoardScreen> createState() => _NoticeBoardScreenState();
}

class _NoticeBoardScreenState extends State<NoticeBoardScreen> {
  List<Notice> _notices = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await TuitionClassApi.notices.list(widget.classroomId);
      final sorted = [...res.results]..sort((a, b) {
          if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
          return b.createdAt.compareTo(a.createdAt);
        });
      if (!mounted) return;
      setState(() => _notices = sorted);
    } on TuitionClassApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _togglePin(Notice n) async {
    try {
      final updated = await TuitionClassApi.notices.pin(n.id);
      if (!mounted) return;
      setState(() {
        _notices = [..._notices.where((x) => x.id != n.id), updated]
          ..sort((a, b) {
            if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
            return b.createdAt.compareTo(a.createdAt);
          });
      });
    } on TuitionClassApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _confirmDelete(Notice n) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete notice?'),
        content: Text('"${n.title}" will be removed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: TuitionClassColors.danger),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final previous = List<Notice>.from(_notices);
    setState(() => _notices.removeWhere((x) => x.id == n.id));
    try {
      await TuitionClassApi.notices.delete(n.id);
    } on TuitionClassApiException catch (e) {
      if (!mounted) return;
      setState(() => _notices = previous);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _openComposeSheet() async {
    // FIX (memory leak): both controllers were created here and never
    // disposed — every "Post Notice" open+close leaked two
    // TextEditingControllers for the app's lifetime. try/finally
    // guarantees disposal on every exit path.
    final titleCtrl = TextEditingController();
    final messageCtrl = TextEditingController();
    try {
      await _showComposeSheet(titleCtrl, messageCtrl);
    } finally {
      titleCtrl.dispose();
      messageCtrl.dispose();
    }
  }

  Future<void> _showComposeSheet(TextEditingController titleCtrl, TextEditingController messageCtrl) async {
    String priority = NoticePriority.normal;
    DateTime? expiresAt;
    bool saving = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(TuitionClassRadius.sheet))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                const Text('Post Notice', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: TuitionClassColors.navy)),
                const SizedBox(height: 16),
                TextField(controller: titleCtrl, decoration: tuitionClassInputDecoration('Title', label: 'Title')),
                const SizedBox(height: 12),
                TextField(controller: messageCtrl, maxLines: 4, decoration: tuitionClassInputDecoration('Message', label: 'Message')),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: priority,
                  decoration: tuitionClassInputDecoration('', label: 'Priority'),
                  items: const [
                    DropdownMenuItem(value: NoticePriority.low, child: Text('Low')),
                    DropdownMenuItem(value: NoticePriority.normal, child: Text('Normal')),
                    DropdownMenuItem(value: NoticePriority.urgent, child: Text('Urgent')),
                  ],
                  onChanged: (v) => setSheet(() => priority = v ?? NoticePriority.normal),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final date = await showDatePicker(
                      context: ctx,
                      initialDate: now.add(const Duration(days: 7)),
                      firstDate: now,
                      lastDate: now.add(const Duration(days: 365)),
                    );
                    if (date != null) setSheet(() => expiresAt = date);
                  },
                  style: OutlinedButton.styleFrom(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14),
                    side: BorderSide(color: Colors.grey.shade300),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TuitionClassRadius.chip)),
                  ),
                  icon: Icon(Icons.timer_off_outlined, color: expiresAt == null ? Colors.grey.shade600 : TuitionClassColors.navy),
                  label: Text(
                    // expiresAt here is a locally-picked DateTime (from showDatePicker),
                    // not one parsed from the API — already in local time, so no
                    // .toLocal() bug like the two calls below. Still switched to the
                    // shared helper for consistent locale-aware formatting.
                    expiresAt == null ? 'Auto-hide date (optional)' : tuitionClassFmtDate(expiresAt!, context),
                    style: TextStyle(color: expiresAt == null ? Colors.grey.shade600 : TuitionClassColors.navy, fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TuitionClassColors.navy,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TuitionClassRadius.chip)),
                    ),
                    onPressed: saving
                        ? null
                        : () async {
                            if (titleCtrl.text.trim().isEmpty || messageCtrl.text.trim().isEmpty) {
                              ScaffoldMessenger.of(ctx)
                                  .showSnackBar(const SnackBar(content: Text('Title and message are required')));
                              return;
                            }
                            setSheet(() => saving = true);
                            try {
                              final n = await TuitionClassApi.notices.create(
                                Notice(
                                  id: 0,
                                  classroomId: widget.classroomId,
                                  postedBy: UserMini(id: 0, username: '', fullName: ''),
                                  title: titleCtrl.text.trim(),
                                  message: messageCtrl.text.trim(),
                                  priority: priority,
                                  createdAt: DateTime.now(),
                                  expiresAt: expiresAt,
                                ),
                              );
                              if (mounted) {
                                setState(() => _notices = [n, ..._notices]);
                                Navigator.pop(ctx);
                              }
                            } on TuitionClassApiException catch (e) {
                              setSheet(() => saving = false);
                              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
                            }
                          },
                    child: saving
                        ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text('Post'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TuitionClassColors.bg,
      appBar: tuitionClassAppBar('Notice Board'),
      floatingActionButton: widget.canManage
          ? FloatingActionButton.extended(
              backgroundColor: TuitionClassColors.navy,
              onPressed: _openComposeSheet,
              icon: const Icon(Icons.campaign_rounded),
              label: const Text('Post'),
            )
          : null,
      body: RefreshIndicator(
        color: TuitionClassColors.navy,
        onRefresh: _load,
        child: _loading
            ? const TuitionClassLoading()
            : _error != null
                ? TuitionClassErrorState(message: _error!, onRetry: _load)
                : _notices.isEmpty
                    ? const TuitionClassEmptyState(icon: Icons.campaign_outlined, title: 'No notices yet')
                    : ListView.builder(
                        padding: EdgeInsets.fromLTRB(16, 14, 16, widget.canManage ? 90 : 24),
                        itemCount: _notices.length,
                        itemBuilder: (ctx, i) {
                          final n = _notices[i];
                          final color = _priorityColor(n.priority);
                          // 🔴 FIX (design-system consistency audit): was a
                          // hand-rolled Container instead of TuitionClassCard —
                          // the priority-colored `border` here is exactly the
                          // case the widget's `border` override was added
                          // for (see the FIX note on TuitionClassCard itself),
                          // so this is a straight swap with zero visual
                          // change: same radius, same shadow token, same
                          // conditional border.
                          return Opacity(
                            opacity: n.isExpired ? 0.55 : 1,
                            child: TuitionClassCard(
                              margin: const EdgeInsets.only(bottom: TuitionClassSpacing.md),
                              padding: const EdgeInsets.all(14),
                              border: Border.all(color: color.withValues(alpha: 0.35)),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      if (n.isPinned) ...[
                                        Icon(Icons.push_pin_rounded, size: 15, color: color),
                                        const SizedBox(width: 4),
                                      ],
                                      Expanded(
                                        child: Text(n.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                      ),
                                      const SizedBox(width: 8),
                                      TuitionClassStatusChip(label: n.priority.toUpperCase(), color: color, background: color.withValues(alpha: 0.12)),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(n.message, style: const TextStyle(fontSize: 13)),
                                  // TASK 9.2/9.3: the automatic "new test" notice links to the test.
                                  if (n.isTestNotice)
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: TextButton.icon(
                                        style: TextButton.styleFrom(
                                          foregroundColor: TuitionClassColors.navy,
                                          padding: EdgeInsets.zero,
                                          minimumSize: const Size(0, 36),
                                        ),
                                        onPressed: () => Navigator.push(
                                          context,
                                          MaterialPageRoute(builder: (_) => TestSeriesDetailScreen(seriesId: n.sourceId!)),
                                        ),
                                        icon: const Icon(Icons.quiz_outlined, size: 18),
                                        label: Text(AppLocalizations.of(context)!.classTestOpen),
                                      ),
                                    ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          // FIX (timezone bug): n.createdAt is UTC from the API —
                                          // see the matching note in doubts_screen.dart. Switched
                                          // to the shared tuitionClassFmtDate() helper.
                                          '${n.postedBy.fullName} · ${tuitionClassFmtDate(n.createdAt, context)}'
                                          '${n.isExpired ? " · Expired" : ""}',
                                          style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      if (widget.canManage) ...[
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          icon: Icon(n.isPinned ? Icons.push_pin_rounded : Icons.push_pin_outlined, color: TuitionClassColors.navy),
                                          onPressed: () => _togglePin(n),
                                        ),
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          icon: const Icon(Icons.delete_outline_rounded, color: TuitionClassColors.danger),
                                          onPressed: () => _confirmDelete(n),
                                        ),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
      ),
    );
  }
}