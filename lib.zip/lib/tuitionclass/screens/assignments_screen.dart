// lib/tuitionclass/screens/assignments_screen.dart
//
// Screen §12 (list half) — Assignments. GET/POST assignments/, DELETE
// assignments/{id}/. Teacher creates (title, description, attachment,
// due_date, max_score); tapping a card opens SubmissionGradingScreen, which
// shows either "submit" (student) or the grading queue (teacher).
//
// Restyled onto the shared TuitionClass design system (tuitionclass_theme.dart)
// so it matches Certificates/Holidays/Coin Wallet instead of falling back
// to plain Material defaults. Logic/API calls unchanged.

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/tuitionclass_models.dart';
import '../services/tuitionclass_api_service.dart';
import '../theme/tuitionclass_theme.dart';
import '../utils/tuitionclass_upload_limits.dart';
import 'submission_grading_screen.dart';

class AssignmentsScreen extends StatefulWidget {
  final int classroomId;
  final int? sessionId;
  final bool canManage; // teacher/co-teacher/moderator

  const AssignmentsScreen({
    super.key,
    required this.classroomId,
    this.sessionId,
    required this.canManage,
  });

  @override
  State<AssignmentsScreen> createState() => _AssignmentsScreenState();
}

class _AssignmentsScreenState extends State<AssignmentsScreen> {
  List<Assignment> _assignments = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await TuitionClassApi.assignments.list(widget.classroomId);
      if (!mounted) return;
      setState(() => _assignments = res.results);
    } on TuitionClassApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _confirmDelete(Assignment a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete assignment?'),
        content: Text('"${a.title}" and its submissions will be removed.'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: TuitionClassColors.danger),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final previous = List<Assignment>.from(_assignments);
    setState(() => _assignments.removeWhere((x) => x.id == a.id));
    try {
      await TuitionClassApi.assignments.delete(a.id);
    } on TuitionClassApiException catch (e) {
      if (!mounted) return;
      setState(() => _assignments = previous);
      _snack(e.message);
    }
  }

  Future<void> _openCreateSheet() async {
    // FIX (memory leak): these three controllers used to be created here
    // and never disposed — every open+close of this sheet leaked three
    // TextEditingControllers for the lifetime of the app. try/finally
    // guarantees disposal on every exit path (submitted, cancelled, or
    // dismissed).
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final scoreCtrl = TextEditingController(text: '100');
    try {
      await _showCreateSheet(titleCtrl, descCtrl, scoreCtrl);
    } finally {
      titleCtrl.dispose();
      descCtrl.dispose();
      scoreCtrl.dispose();
    }
  }

  Future<void> _showCreateSheet(
    TextEditingController titleCtrl,
    TextEditingController descCtrl,
    TextEditingController scoreCtrl,
  ) async {
    DateTime? dueDate;
    PlatformFile? attachment;
    bool saving = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(TuitionClassRadius.sheet))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                const Text('New Assignment', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: TuitionClassColors.navy)),
                const SizedBox(height: 16),
                TextField(controller: titleCtrl, decoration: tuitionClassInputDecoration('e.g. Week 3 problem set', label: 'Title')),
                const SizedBox(height: 12),
                TextField(
                  controller: descCtrl,
                  maxLines: 3,
                  decoration: tuitionClassInputDecoration('What should students do?', label: 'Description'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: scoreCtrl,
                  keyboardType: TextInputType.number,
                  decoration: tuitionClassInputDecoration('100', label: 'Max score'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final date = await showDatePicker(
                      context: ctx,
                      initialDate: now.add(const Duration(days: 3)),
                      firstDate: now,
                      lastDate: now.add(const Duration(days: 365)),
                    );
                    if (date == null) return;
                    if (!ctx.mounted) return;
                    final time = await showTimePicker(context: ctx, initialTime: const TimeOfDay(hour: 23, minute: 59));
                    setSheet(() => dueDate = DateTime(date.year, date.month, date.day, time?.hour ?? 23, time?.minute ?? 59));
                  },
                  style: OutlinedButton.styleFrom(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14),
                    side: BorderSide(color: Colors.grey.shade300),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TuitionClassRadius.chip)),
                  ),
                  icon: Icon(Icons.event_rounded, color: dueDate == null ? Colors.grey.shade600 : TuitionClassColors.navy),
                  label: Text(
                    dueDate == null ? 'Set due date' : tuitionClassFmtDateTime(dueDate!, ctx),
                    style: TextStyle(color: dueDate == null ? Colors.grey.shade600 : TuitionClassColors.navy, fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    // FIX (file upload size/type audit): no extension
                    // restriction and no size check at all before — a
                    // teacher could attach anything of any size, only
                    // discovering the backend's real 50MB/safelist
                    // rejection after a full, potentially very slow
                    // upload attempt (Assignment.attachment's
                    // MaxFileSizeValidator(50) + DOCUMENT_MEDIA_EXTENSIONS
                    // in models.py). Scoping the picker itself to the
                    // allowed extensions AND re-checking size/type on the
                    // result catches this immediately, locally.
                    final res = await FilePicker.platform.pickFiles(
                      type: FileType.custom,
                      allowedExtensions: TuitionClassUploadLimits.documentExtensions,
                    );
                    if (res == null || res.files.isEmpty) return;
                    final picked = res.files.first;
                    final error = TuitionClassUploadLimits.checkPlatformFile(
                      picked,
                      maxMB: TuitionClassUploadLimits.assignmentAttachmentMaxMB,
                      allowedExtensions: TuitionClassUploadLimits.documentExtensions,
                    );
                    if (error != null) {
                      if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(error)));
                      return;
                    }
                    setSheet(() => attachment = picked);
                  },
                  style: OutlinedButton.styleFrom(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14),
                    side: BorderSide(color: Colors.grey.shade300),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TuitionClassRadius.chip)),
                  ),
                  icon: Icon(Icons.attach_file_rounded, color: attachment == null ? Colors.grey.shade600 : TuitionClassColors.navy),
                  label: Text(
                    attachment?.name ?? 'Attach file (optional)',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: attachment == null ? Colors.grey.shade600 : TuitionClassColors.navy, fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TuitionClassColors.navy,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TuitionClassRadius.chip)),
                    ),
                    onPressed: saving
                        ? null
                        : () async {
                            if (titleCtrl.text.trim().isEmpty || dueDate == null) {
                              ScaffoldMessenger.of(ctx)
                                  .showSnackBar(const SnackBar(content: Text('Title and due date are required')));
                              return;
                            }
                            final maxScore = int.tryParse(scoreCtrl.text.trim()) ?? 100;
                            setSheet(() => saving = true);
                            try {
                              final a = await TuitionClassApi.assignments.create(
                                Assignment(
                                  id: 0,
                                  classroomId: widget.classroomId,
                                  sessionId: widget.sessionId,
                                  title: titleCtrl.text.trim(),
                                  description: descCtrl.text.trim(),
                                  dueDate: dueDate!,
                                  maxScore: maxScore,
                                  createdAt: DateTime.now(),
                                ),
                                attachmentPath: attachment?.path,
                              );
                              if (mounted) {
                                setState(() => _assignments = [a, ..._assignments]);
                                Navigator.pop(ctx);
                              }
                            } on TuitionClassApiException catch (e) {
                              setSheet(() => saving = false);
                              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
                            }
                          },
                    child: saving
                        ? const SizedBox(
                            height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text('Create'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // FIX (i18n / timezone audit — see utils/tuitionclass_datetime.dart / the
  // matching fix already applied in doubts_screen.dart, holidays_screen.dart,
  // submission_grading_screen.dart etc.): this used to be a hand-rolled
  // formatter reading `.day`/`.month`/`.hour` straight off `a.dueDate`, which
  // comes from the API as a UTC DateTime (see tuitionclass_models.dart's
  // parsing) — with no `.toLocal()` call, and against the deprecated,
  // English-only `kTuitionClassMonths` array. A due date set for 11:59 PM IST
  // rendered hours off (and only in English) for every viewer. Every call
  // site below now goes through the shared, locale + timezone-safe
  // `tuitionClassFmtDateTime()` helper this file already imports from
  // tuitionclass_theme.dart instead.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TuitionClassColors.bg,
      appBar: tuitionClassAppBar('Assignments'),
      floatingActionButton: widget.canManage
          ? FloatingActionButton.extended(
              backgroundColor: TuitionClassColors.navy,
              onPressed: _openCreateSheet,
              icon: const Icon(Icons.add_rounded),
              label: const Text('New'),
            )
          : null,
      body: RefreshIndicator(
        color: TuitionClassColors.navy,
        onRefresh: _load,
        child: _loading
            ? const TuitionClassLoading()
            : _error != null
                ? TuitionClassErrorState(message: _error!, onRetry: _load)
                : _assignments.isEmpty
                    ? const TuitionClassEmptyState(
                        icon: Icons.assignment_outlined,
                        title: 'No assignments yet',
                        subtitle: 'Assignments you create will show up here.',
                      )
                    : ListView.builder(
                        padding: EdgeInsets.fromLTRB(16, 14, 16, widget.canManage ? 90 : 24),
                        itemCount: _assignments.length,
                        itemBuilder: (ctx, i) {
                          final a = _assignments[i];
                          final overdue = DateTime.now().isAfter(a.dueDate);
                          return TuitionClassCard(
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SubmissionGradingScreen(assignment: a, canManage: widget.canManage),
                              ),
                            ),
                            child: Row(
                              children: [
                                TuitionClassIconBadge(icon: Icons.assignment_rounded, size: 44),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(a.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.event_rounded, size: 13, color: overdue ? TuitionClassColors.danger : Colors.grey.shade500),
                                          const SizedBox(width: 4),
                                          Text(
                                            'Due ${tuitionClassFmtDateTime(a.dueDate, ctx)}',
                                            style: TextStyle(
                                              fontSize: 11.5,
                                              color: overdue ? TuitionClassColors.danger : Colors.grey.shade500,
                                              fontWeight: overdue ? FontWeight.w600 : FontWeight.normal,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        children: [
                                          if (overdue) ...[
                                            const TuitionClassStatusChip(label: 'PAST DUE', color: TuitionClassColors.danger, background: TuitionClassColors.dangerBg),
                                            const SizedBox(width: 6),
                                          ],
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                            decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(8)),
                                            child: Text('Max ${a.maxScore}', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: Colors.grey.shade700)),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 6),
                                widget.canManage
                                    ? IconButton(
                                        icon: const Icon(Icons.delete_outline_rounded, color: TuitionClassColors.danger),
                                        onPressed: () => _confirmDelete(a),
                                      )
                                    : Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                              ],
                            ),
                          );
                        },
                      ),
      ),
    );
  }
}