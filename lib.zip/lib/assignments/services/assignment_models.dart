// ============================================================
// ASSIGNMENTS — DATA MODELS
//
// Backend: `assigments` app (haan, backend me spelling isi tarah hai —
// `assigments`, ek 'n' kam. URLs aur JSON keys wahi spelling use karti
// hain, isliye yahan bhi jaan-boojh kar wahi likha hai; sirf Dart-side
// class/field naam sahi spelling me hain).
//
// Field list source: ASSIGNMENT_APP_MASTER.md ke serializers —
//   assigmentsSerializer / assigmentsQuestionSerializer /
//   assigmentsSubmissionSerializer / assigmentsAnswerSerializer.
// ============================================================

/// `assigmentsQuestion.QuestionTypeChoices` — text/mcq/msq/list.
enum AssignmentQuestionType { text, mcq, msq, list, unknown }

AssignmentQuestionType assignmentQuestionTypeFrom(String? raw) {
  switch (raw) {
    case 'text':
      return AssignmentQuestionType.text;
    case 'mcq':
      return AssignmentQuestionType.mcq;
    case 'msq':
      return AssignmentQuestionType.msq;
    case 'list':
      return AssignmentQuestionType.list;
    default:
      return AssignmentQuestionType.unknown;
  }
}

/// `assigmentsSubmission.SubmissionStatus`.
enum AssignmentStatus { missing, submitted, late, partiallyChecked, checked, unknown }

AssignmentStatus assignmentStatusFrom(String? raw) {
  switch (raw) {
    case 'missing':
      return AssignmentStatus.missing;
    case 'submitted':
      return AssignmentStatus.submitted;
    case 'late':
      return AssignmentStatus.late;
    case 'partially_checked':
      return AssignmentStatus.partiallyChecked;
    case 'checked':
      return AssignmentStatus.checked;
    default:
      return AssignmentStatus.unknown;
  }
}

/// Ek selectable option. Backend `options` ko "opaque list" maanta hai:
/// tests `[{"id": "opt_4", "text": "4"}]` shape use karte hain, par model
/// comment plain `["opt_a", "opt_b"]` bhi allow karta hai. Isliye parser
/// dono shapes handle karta hai — warna ek hi legacy assignment poori
/// screen crash kara deta.
class AssignmentOption {
  final String id;
  final String text;
  const AssignmentOption({required this.id, required this.text});

  factory AssignmentOption.fromAny(dynamic raw, int index) {
    if (raw is Map) {
      final id = (raw['id'] ?? raw['value'] ?? '$index').toString();
      final text = (raw['text'] ?? raw['label'] ?? id).toString();
      return AssignmentOption(id: id, text: text);
    }
    final s = raw?.toString() ?? '$index';
    return AssignmentOption(id: s, text: s);
  }
}

class AssignmentQuestion {
  final String id;
  final int order;
  final AssignmentQuestionType type;
  final String text;
  final String? attachment;
  final int marks;
  final List<AssignmentOption> options;

  const AssignmentQuestion({
    required this.id,
    required this.order,
    required this.type,
    required this.text,
    required this.marks,
    required this.options,
    this.attachment,
  });

  factory AssignmentQuestion.fromJson(Map<String, dynamic> j) {
    final rawOptions = j['options'];
    return AssignmentQuestion(
      id: j['id']?.toString() ?? '',
      order: (j['order'] as num?)?.toInt() ?? 0,
      type: assignmentQuestionTypeFrom(j['question_type']?.toString()),
      text: j['text']?.toString() ?? '',
      attachment: (j['attachment']?.toString().isNotEmpty ?? false) ? j['attachment'].toString() : null,
      marks: (j['marks'] as num?)?.toInt() ?? 0,
      options: rawOptions is List
          ? List.generate(rawOptions.length, (i) => AssignmentOption.fromAny(rawOptions[i], i))
          : const [],
    );
  }
}

/// `assigmentsKind` — classic task vs a longer project (link/file hand-in,
/// graded against a rubric).
enum AssignmentKind { assignment, project, unknown }

AssignmentKind assignmentKindFrom(String? raw) {
  switch (raw) {
    case 'assignment':
      return AssignmentKind.assignment;
    case 'project':
      return AssignmentKind.project;
    default:
      return AssignmentKind.unknown;
  }
}

/// `assigmentsStatus` — draft/published/archived. Only meaningful for
/// `source == personal`; campus/tuitionclass assignments don't use this flow.
enum AssignmentPublishStatus { draft, published, archived, unknown }

AssignmentPublishStatus assignmentPublishStatusFrom(String? raw) {
  switch (raw) {
    case 'draft':
      return AssignmentPublishStatus.draft;
    case 'published':
      return AssignmentPublishStatus.published;
    case 'archived':
      return AssignmentPublishStatus.archived;
    default:
      return AssignmentPublishStatus.unknown;
  }
}

/// `assigmentsVisibility` — who can find/open a PERSONAL assignment.
enum AssignmentVisibility { private_, link, public, unknown }

AssignmentVisibility assignmentVisibilityFrom(String? raw) {
  switch (raw) {
    case 'private':
      return AssignmentVisibility.private_;
    case 'link':
      return AssignmentVisibility.link;
    case 'public':
      return AssignmentVisibility.public;
    default:
      return AssignmentVisibility.unknown;
  }
}

class AssignmentModel {
  final String id;
  final String title;
  final String description;
  final String? attachment;
  final DateTime? dueDate;
  final int totalMarks;
  final bool hasStructuredQuestions;
  final String postedBy;
  final String source; // personal / campus / tuitionclass
  final List<AssignmentQuestion> questions;
  final DateTime? createdAt;

  // ---- publishing + projects (migration 0003) ----
  final AssignmentKind kind;
  final AssignmentPublishStatus status;
  final AssignmentVisibility visibility;
  final String? publicSlug;
  final String? shareUrl;
  final DateTime? publishedAt;
  final List<String> tags;
  final String difficulty;

  /// Which hand-in types this assignment accepts — `text` / `file` / `link`.
  /// Empty list = all types allowed.
  final List<String> submissionTypes;

  /// Project grading rubric: `[{criterion, max_marks}, ...]`.
  final List<Map<String, dynamic>> rubric;
  final int participantsCount;

  const AssignmentModel({
    required this.id,
    required this.title,
    required this.description,
    required this.totalMarks,
    required this.hasStructuredQuestions,
    required this.postedBy,
    required this.source,
    required this.questions,
    this.attachment,
    this.dueDate,
    this.createdAt,
    this.kind = AssignmentKind.assignment,
    this.status = AssignmentPublishStatus.draft,
    this.visibility = AssignmentVisibility.private_,
    this.publicSlug,
    this.shareUrl,
    this.publishedAt,
    this.tags = const [],
    this.difficulty = '',
    this.submissionTypes = const [],
    this.rubric = const [],
    this.participantsCount = 0,
  });

  factory AssignmentModel.fromJson(Map<String, dynamic> j) {
    final q = j['questions'];
    final slug = j['public_slug']?.toString() ?? '';
    final url = j['share_url']?.toString() ?? '';
    final tags = j['tags'];
    final types = j['submission_types'];
    final rubric = j['rubric'];
    return AssignmentModel(
      id: j['id']?.toString() ?? '',
      title: j['title']?.toString() ?? '',
      description: j['description']?.toString() ?? '',
      attachment: (j['attachment']?.toString().isNotEmpty ?? false) ? j['attachment'].toString() : null,
      dueDate: DateTime.tryParse(j['due_date']?.toString() ?? ''),
      totalMarks: (j['total_marks'] as num?)?.toInt() ?? 0,
      hasStructuredQuestions: j['has_structured_questions'] == true,
      postedBy: j['posted_by']?.toString() ?? '',
      source: j['source']?.toString() ?? 'personal',
      questions: q is List
          ? q.map((e) => AssignmentQuestion.fromJson(Map<String, dynamic>.from(e as Map))).toList()
          : const [],
      createdAt: DateTime.tryParse(j['created_at']?.toString() ?? ''),
      kind: assignmentKindFrom(j['kind']?.toString()),
      status: assignmentPublishStatusFrom(j['status']?.toString()),
      visibility: assignmentVisibilityFrom(j['visibility']?.toString()),
      publicSlug: slug.isNotEmpty ? slug : null,
      shareUrl: url.isNotEmpty ? url : null,
      publishedAt: DateTime.tryParse(j['published_at']?.toString() ?? ''),
      tags: tags is List ? tags.map((e) => e.toString()).toList() : const [],
      difficulty: j['difficulty']?.toString() ?? '',
      submissionTypes: types is List ? types.map((e) => e.toString()).toList() : const [],
      rubric: rubric is List ? rubric.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : const [],
      participantsCount: (j['participants_count'] as num?)?.toInt() ?? 0,
    );
  }

  bool get isOverdue => dueDate != null && DateTime.now().isAfter(dueDate!);

  /// Due date se kitne din bache — negative = overdue. `null` = koi due
  /// date hi nahi.
  int? get daysLeft {
    if (dueDate == null) return null;
    final now = DateTime.now();
    final d = DateTime(dueDate!.year, dueDate!.month, dueDate!.day);
    final t = DateTime(now.year, now.month, now.day);
    return d.difference(t).inDays;
  }

  bool get isProject => kind == AssignmentKind.project;
  bool get isPublished => status == AssignmentPublishStatus.published;

  /// `submission_types` khaali ho to sab allowed hain.
  bool acceptsSubmissionType(String type) => submissionTypes.isEmpty || submissionTypes.contains(type);
}

class AssignmentAnswer {
  final String id;
  final String questionId;
  final String questionText;
  final int questionMarks;
  final dynamic answerData;
  final String? answerAttachment;
  final bool isAutoGraded;
  final bool? isCorrect;
  final int? marksAwarded;
  final String reviewerFeedback;

  const AssignmentAnswer({
    required this.id,
    required this.questionId,
    required this.questionText,
    required this.questionMarks,
    required this.answerData,
    required this.isAutoGraded,
    required this.reviewerFeedback,
    this.answerAttachment,
    this.isCorrect,
    this.marksAwarded,
  });

  factory AssignmentAnswer.fromJson(Map<String, dynamic> j) {
    return AssignmentAnswer(
      id: j['id']?.toString() ?? '',
      questionId: j['question']?.toString() ?? '',
      questionText: j['question_text']?.toString() ?? '',
      questionMarks: (j['question_marks'] as num?)?.toInt() ?? 0,
      answerData: j['answer_data'],
      answerAttachment:
          (j['answer_attachment']?.toString().isNotEmpty ?? false) ? j['answer_attachment'].toString() : null,
      isAutoGraded: j['is_auto_graded'] == true,
      isCorrect: j['is_correct'] is bool ? j['is_correct'] as bool : null,
      marksAwarded: (j['marks_awarded'] as num?)?.toInt(),
      reviewerFeedback: j['reviewer_feedback']?.toString() ?? '',
    );
  }

  /// `text` question jo abhi tak teacher ne review nahi kiya.
  bool get awaitingReview => !isAutoGraded && marksAwarded == null;
}

class AssignmentSubmission {
  final String id;
  final String assignmentId;
  final String student;
  final String writtenContent;
  final String? file;
  final AssignmentStatus status;
  final String grade;
  final int? totalMarksAwarded;
  final String feedback;
  final String publicSlug;
  final DateTime? submittedAt;
  final DateTime? checkedAt;
  final bool isLate;
  final List<AssignmentAnswer> answers;

  /// Project hand-in link (repo / live demo / design file) — free-form path.
  final String linkUrl;

  /// Project rubric grading: `{criterion: marks_awarded}`.
  final Map<String, int> rubricScores;

  const AssignmentSubmission({
    required this.id,
    required this.assignmentId,
    required this.student,
    required this.writtenContent,
    required this.status,
    required this.grade,
    required this.feedback,
    required this.publicSlug,
    required this.isLate,
    required this.answers,
    this.file,
    this.totalMarksAwarded,
    this.submittedAt,
    this.checkedAt,
    this.linkUrl = '',
    this.rubricScores = const {},
  });

  factory AssignmentSubmission.fromJson(Map<String, dynamic> j) {
    final a = j['answers'];
    final scores = j['rubric_scores'];
    return AssignmentSubmission(
      id: j['id']?.toString() ?? '',
      assignmentId: j['assigments']?.toString() ?? '',
      student: j['student']?.toString() ?? '',
      writtenContent: j['written_content']?.toString() ?? '',
      file: (j['file']?.toString().isNotEmpty ?? false) ? j['file'].toString() : null,
      status: assignmentStatusFrom(j['status']?.toString()),
      grade: j['grade']?.toString() ?? '',
      totalMarksAwarded: (j['total_marks_awarded'] as num?)?.toInt(),
      feedback: j['feedback']?.toString() ?? '',
      publicSlug: j['public_slug']?.toString() ?? '',
      submittedAt: DateTime.tryParse(j['submitted_at']?.toString() ?? ''),
      checkedAt: DateTime.tryParse(j['checked_at']?.toString() ?? ''),
      isLate: j['is_late'] == true,
      linkUrl: j['link_url']?.toString() ?? '',
      rubricScores: scores is Map
          ? scores.map((k, v) => MapEntry(k.toString(), (v as num?)?.toInt() ?? 0))
          : const {},
      answers: a is List
          ? a.map((e) => AssignmentAnswer.fromJson(Map<String, dynamic>.from(e as Map))).toList()
          : const [],
    );
  }

  bool get isSubmitted => status != AssignmentStatus.missing && submittedAt != null;
  bool get isFullyChecked => status == AssignmentStatus.checked;
  bool get isPending => status == AssignmentStatus.missing;
}

/// `SubmissionSimilarityFlag.Status` — Task 6 Part C.
enum SimilarityFlagStatus { pending, confirmed, dismissed, unknown }

SimilarityFlagStatus similarityFlagStatusFrom(String? raw) {
  switch (raw) {
    case 'pending':
      return SimilarityFlagStatus.pending;
    case 'confirmed':
      return SimilarityFlagStatus.confirmed;
    case 'dismissed':
      return SimilarityFlagStatus.dismissed;
    default:
      return SimilarityFlagStatus.unknown;
  }
}

/// `SubmissionSimilarityFlagSerializer` — Task 6 Part C (frontend half of
/// the "Assignment Duplicate/Plagiarism Flag" feature; backend Parts A
/// [`plagiarism.py` engine + `SubmissionSimilarityFlag` model] and B [auto-
/// run-on-submit + these two teacher endpoints] are already done — see
/// `backend/assigments/plagiarism.py`'s own docstring for the full split).
///
/// One row = one OTHER submission this submission looks like a possible
/// duplicate of. `otherSubmissionId`/`otherStudent`/`myExcerpt`/
/// `otherExcerpt` are already computed by the backend "from this
/// submission's side of the pair" (it sends `viewed_submission_id` as
/// context) — Flutter never has to figure out which side of `submission_a`
/// / `submission_b` it's looking at.
class SimilarityFlag {
  final String id;
  final String otherSubmissionId;
  final String otherStudent;

  /// Set only for a structured `text`-question match; `null` means this
  /// flag came from comparing whole free-form `written_content` instead
  /// (mirrors the backend model's own `question` field — null there means
  /// exactly the same thing).
  final String? questionId;
  final String questionText;

  /// 0.0–1.0 `difflib.SequenceMatcher` ratio — `plagiarism.
  /// SIMILARITY_THRESHOLD` (0.75) is the backend's own cutoff for a flag
  /// to exist at all, so anything reaching this class is already at or
  /// above that.
  final double similarityScore;
  final String myExcerpt;
  final String otherExcerpt;
  final SimilarityFlagStatus status;
  final String? reviewedBy;
  final DateTime? reviewedAt;
  final DateTime? createdAt;

  const SimilarityFlag({
    required this.id,
    required this.otherSubmissionId,
    required this.otherStudent,
    required this.questionText,
    required this.similarityScore,
    required this.myExcerpt,
    required this.otherExcerpt,
    required this.status,
    this.questionId,
    this.reviewedBy,
    this.reviewedAt,
    this.createdAt,
  });

  factory SimilarityFlag.fromJson(Map<String, dynamic> j) {
    return SimilarityFlag(
      id: j['id']?.toString() ?? '',
      otherSubmissionId: j['other_submission_id']?.toString() ?? '',
      otherStudent: j['other_student']?.toString() ?? '',
      questionId: (j['question']?.toString().isNotEmpty ?? false) ? j['question'].toString() : null,
      questionText: j['question_text']?.toString() ?? '',
      similarityScore: (j['similarity_score'] as num?)?.toDouble() ?? 0.0,
      myExcerpt: j['my_excerpt']?.toString() ?? '',
      otherExcerpt: j['other_excerpt']?.toString() ?? '',
      status: similarityFlagStatusFrom(j['status']?.toString()),
      reviewedBy: (j['reviewed_by']?.toString().isNotEmpty ?? false) ? j['reviewed_by'].toString() : null,
      reviewedAt: DateTime.tryParse(j['reviewed_at']?.toString() ?? ''),
      createdAt: DateTime.tryParse(j['created_at']?.toString() ?? ''),
    );
  }

  bool get isPending => status == SimilarityFlagStatus.pending;

  /// True = whole-submission (free-form `written_content`) comparison;
  /// false = one specific structured `text` question.
  bool get isFreeform => questionId == null;
}

/// Ek assignment + us par MERI submission — list screen ko dono chahiye
/// hote hain (kya submit karna baaki hai / kitne marks mile), par backend
/// do alag endpoints deta hai. Ye pair client-side me banti hai
/// (`AssignmentService.getMyAssignments()`).
class AssignmentWithSubmission {
  final AssignmentModel assignment;
  final AssignmentSubmission? submission;
  const AssignmentWithSubmission({required this.assignment, this.submission});

  AssignmentStatus get effectiveStatus => submission?.status ?? AssignmentStatus.missing;
  bool get isPending => submission == null || submission!.isPending;
  bool get isChecked =>
      submission != null &&
      (submission!.status == AssignmentStatus.checked ||
          submission!.status == AssignmentStatus.partiallyChecked);
  bool get isSubmitted => submission != null && submission!.isSubmitted && !isChecked;
}
