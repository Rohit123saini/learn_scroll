import 'dart:convert';
import 'dart:io';
import 'dart:typed_data'; // 🔧 FIX (Task 7) — BytesBuilder for race-free chunk reads
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/auth_service.dart';
import '../../utils/api.dart';
import '../models/models.dart';

class ApiService {
  // 🔥 NAYA — chunked upload (4GB tak, comment_view.py ke chunked upload jaisa hi)
  // 5MB ka ek chunk. Bade video/file ke liye normal multipart ki jagah isse use karo.
  static const int _chunkSize = 5 * 1024 * 1024;
  // Ek saath max itne chunks parallel me upload honge (speed vs server load ka balance).
  static const int _parallelChunkUploads = 4;
  // SharedPreferences me resume-fingerprint save karne ki key ka prefix.
  static const String _resumePrefsPrefix = 'chunked_upload_resume_';

  Future<Map<String, dynamic>> createPost({
    String? title,
    required String content,
    required String category,
    String? subcategory,
    required String postType,
    String visibility = 'public',
    List<String>? hashtags,
    Map<String, dynamic>? location,
    List<File>? mediaFiles,
    List<String>? mediaTypes,
    List<String>? mediaCaptions, // 🔥 NAYA — per-attachment captions
    List<Map<String, dynamic>>? pollOptions, // 🔥 NAYA — poll post support
    DateTime? scheduledAt, // 🔥 NAYA — new_post.dart isko already pass kar raha tha, param yahan missing tha
  }) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    var uri = Uri.parse('${Api.baseUrl}/post/create/');
    var request = http.MultipartRequest('POST', uri);
    request.headers['Authorization'] = 'Bearer $token';
    if (title!= null && title.isNotEmpty) {
      request.fields['title'] = title;
    }
    request.fields['content'] = content;
    request.fields['category'] = category;
    if (subcategory != null && subcategory.isNotEmpty) {
      request.fields['subcategory'] = subcategory;
    }
    request.fields['post_type'] = postType;
    request.fields['visibility'] = visibility;
    // 🔥 NAYA — scheduled post
    if (scheduledAt != null) {
      request.fields['scheduled_at'] = scheduledAt.toIso8601String();
      request.fields['is_scheduled'] = 'true';
    }
    // 🔥 FIX — pehle loop me `request.fields['hashtags']` baar-baar overwrite ho raha
    // tha, isliye sirf AAKHRI hashtag hi backend tak jaata tha. `location` jaisa hi
    // JSON list bhej rahe hain ab.
    if (hashtags!= null && hashtags.isNotEmpty) {
      request.fields['hashtags'] = jsonEncode(hashtags);
    }
    if (location!= null) {
      request.fields['location'] = jsonEncode(location);
    }
    if (mediaFiles!= null && mediaFiles.isNotEmpty) {
      for (int i = 0; i < mediaFiles.length; i++) {
        var file = mediaFiles[i];
        request.files.add(await http.MultipartFile.fromPath('media_files', file.path));
      }
      // 🔥 FIX — `media_types` bhi isi tarah overwrite ho raha tha, sirf last file
      // ka type save hota tha. Ab poori list JSON ke roop me, files ke saath
      // same order me bhej rahe hain.
      if (mediaTypes != null && mediaTypes.isNotEmpty) {
        request.fields['media_types'] = jsonEncode(mediaTypes);
      }
      // 🔥 NAYA — per-attachment captions, same order as media_files
      if (mediaCaptions != null && mediaCaptions.isNotEmpty) {
        request.fields['media_captions'] = jsonEncode(mediaCaptions);
      }
    }
    // 🔥 NAYA — poll options
    if (pollOptions != null && pollOptions.isNotEmpty) {
      request.fields['poll_options'] = jsonEncode(pollOptions);
    }
    try {
      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);
      // Non-JSON body (proxy/HTML error page) must not surface as a raw
      // FormatException — show a readable status instead.
      dynamic data;
      try {
        data = jsonDecode(utf8.decode(response.bodyBytes));
      } catch (_) {
        throw Exception('Server error (${response.statusCode}). Please try again.');
      }
      if (response.statusCode == 201) {
        return data;
      } else {
        // Backend sends a field-specific `message` on 400 (e.g. which
        // category value was rejected) — surface that, not a generic text.
        throw Exception((data is Map ? data['message'] : null) ?? 'Failed to create post');
      }
    } catch (e) {
      if (e is Exception) rethrow;
      throw Exception('Network error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // CHUNKED UPLOAD — POST (badi files, e.g. video, 4GB tak)
  // ═══════════════════════════════════════════════════════════════

  Future<String> initPostChunkedUpload({
    required File file,
    String? title,
    required String content,
    required String category,
    String? subcategory,
    required String postType,
    String visibility = 'public',
    List<String>? hashtags,
    Map<String, dynamic>? location,
    List<Map<String, dynamic>>? pollOptions,
    String? mediaCaption,
    String? mediaType,
    DateTime? scheduledAt,
  }) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final totalSize = await file.length();
    final totalChunks = (totalSize / _chunkSize).ceil();

    final uri = Uri.parse('${Api.baseUrl}/post/chunked/init/');
    final response = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'file_name': file.path.split('/').last,
        'total_chunks': totalChunks,
        'total_size': totalSize,
        'title': title ?? '',
        'content': content,
        'category': category,
        'subcategory': subcategory,
        'post_type': postType,
        'visibility': visibility,
        'hashtags': hashtags ?? [],
        'location': location ?? {},
        'poll_options': pollOptions ?? [],
        'media_caption': mediaCaption ?? '',
        'media_type': mediaType,
        'is_scheduled': scheduledAt != null,
        if (scheduledAt != null) 'scheduled_at': scheduledAt.toIso8601String(),
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) return data['upload_id'];
    throw Exception(data['error'] ?? 'Chunked upload shuru nahi ho paya');
  }

  // NOTE: ye comment ka hi generic chunk endpoint reuse karta hai — usse sirf
  // upload_id + chunk_index chahiye, post ho ya comment fark nahi padta.
  Future<void> uploadPostChunk({
    required String uploadId,
    required int chunkIndex,
    required List<int> chunkBytes,
  }) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final uri = Uri.parse('${Api.baseUrl}/post/comment/chunked/chunk/');
    var request = http.MultipartRequest('POST', uri);
    request.headers['Authorization'] = 'Bearer $token';
    request.fields['upload_id'] = uploadId;
    request.fields['chunk_index'] = chunkIndex.toString();
    // 🔥 NAYA — is chunk ka MD5 hash bhi bhejte hain, taaki server verify kar
    // sake ki network me chunk corrupt to nahi hua. Mismatch pe server 400
    // deta hai aur is chunk ko received nahi maanta — humara resume logic
    // (upload_id reuse) isse automatically dubara try kar leta hai.
    request.fields['chunk_hash'] = md5.convert(chunkBytes).toString();
    request.files.add(http.MultipartFile.fromBytes('chunk', chunkBytes, filename: 'chunk_$chunkIndex'));

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['error'] ?? 'Chunk $chunkIndex upload fail hua');
    }
  }

  Future<Map<String, dynamic>> completePostChunkedUpload(String uploadId) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final uri = Uri.parse('${Api.baseUrl}/post/chunked/complete/');
    final response = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'upload_id': uploadId}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 201) return data;
    throw Exception(data['message'] ?? data['error'] ?? 'Post complete nahi ho paya');
  }

  // 🔥 NAYA — resume support: batata hai is upload_id ke kaunse chunks already
  // server pe save ho chuke hain. Comment aur post dono flow ke liye generic hai.
  Future<Map<String, dynamic>> getChunkedUploadStatus(String uploadId) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final uri = Uri.parse('${Api.baseUrl}/post/chunked/status/$uploadId/');
    final response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) {
      throw Exception('Upload status nahi mila (shayad expire ho gaya)');
    }
    return jsonDecode(response.body);
  }

  // File ka fingerprint — path + size + last-modified se bana, taaki same file
  // dubara select karne pe hum pehchan sakein ki ye wahi ruka hua upload hai.
  Future<String> _fileFingerprint(File file) async {
    final stat = await file.stat();
    return '${file.path}_${stat.size}_${stat.modified.millisecondsSinceEpoch}';
  }

  /// High-level helper: file ko disk se seekhte hue chunks me padhta hai
  /// (poori file ek saath RAM me load nahi karta — 4GB file ke liye zaroori),
  /// chunks ko **parallel** (max `_parallelChunkUploads` ek saath) upload
  /// karta hai speed ke liye, phir complete call karke Post banata hai.
  ///
  /// 🔥 NAYA — RESUME SUPPORT: agar pehle isi file ka upload beech me
  /// ruk gaya tha (app band ho gayi, network gaya), to ye automatically
  /// wahi upload_id reuse karega aur sirf **missing chunks** dubara bhejega,
  /// poori file dubara se nahi.
  ///
  /// `onProgress` 0.0 -> 1.0 ke beech progress deta hai.
  Future<Map<String, dynamic>> createPostWithChunkedUpload({
    required File file,
    String? title,
    required String content,
    required String category,
    String? subcategory,
    required String postType,
    String visibility = 'public',
    List<String>? hashtags,
    Map<String, dynamic>? location,
    List<Map<String, dynamic>>? pollOptions,
    String? mediaCaption,
    String? mediaType,
    DateTime? scheduledAt,
    void Function(double progress)? onProgress,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final fingerprint = await _fileFingerprint(file);
    final prefsKey = '$_resumePrefsPrefix$fingerprint';

    final totalSize = await file.length();
    final totalChunks = (totalSize / _chunkSize).ceil();

    String? uploadId = prefs.getString(prefsKey);
    Set<int> alreadyReceived = {};

    if (uploadId != null) {
      // Purana ruka hua upload mila — check karo ki server pe abhi bhi valid hai
      try {
        final statusData = await getChunkedUploadStatus(uploadId);
        if (statusData['is_completed'] == true) {
          // Pehle hi complete ho chuka tha par local state clear nahi hui —
          // fresh upload shuru karo taaki duplicate post na bane.
          uploadId = null;
        } else {
          alreadyReceived = Set<int>.from((statusData['received_chunks'] as List).map((e) => e as int));
        }
      } catch (_) {
        // upload_id ab valid nahi (expire/cleanup ho gaya) — fresh shuru karo
        uploadId = null;
      }
    }

    if (uploadId == null) {
      uploadId = await initPostChunkedUpload(
        file: file,
        title: title,
        content: content,
        category: category,
        subcategory: subcategory,
        postType: postType,
        visibility: visibility,
        hashtags: hashtags,
        location: location,
        pollOptions: pollOptions,
        mediaCaption: mediaCaption,
        mediaType: mediaType,
        scheduledAt: scheduledAt,
      );
      alreadyReceived = {};
      // Turant save karo — taaki agar chunking ke beech me app crash ho jaye,
      // agli baar isi upload_id se resume ho sake.
      await prefs.setString(prefsKey, uploadId);
    }

    final pending = List<int>.generate(totalChunks, (i) => i).where((i) => !alreadyReceived.contains(i)).toList();

    int completedCount = alreadyReceived.length;
    void reportProgress() => onProgress?.call(completedCount / totalChunks);
    reportProgress();

    // 🔧 FIX (Task 7 — video upload bug): this used to open ONE shared
    // `RandomAccessFile` and do `await raf.setPosition(start); await
    // raf.read(size);` for every chunk, including the up-to-4 chunks
    // that run **concurrently** in the `Future.wait` batch below. That
    // raced: `setPosition` and `read` are two separate awaited calls on
    // the SAME file handle, so between one chunk-task's `setPosition`
    // and its own `read`, the event loop could run a DIFFERENT
    // concurrent chunk-task's `setPosition` first — moving the shared
    // cursor — and this task's `read` would then return bytes for the
    // WRONG offset (sometimes another chunk's data, sometimes a
    // mid-chunk splice). The server correctly caught this as a
    // `chunk_hash` mismatch (400) and the existing per-chunk retry
    // above would re-run the same racy read, so it re-corrupted about
    // as often as it succeeded — exactly the kind of intermittent,
    // no-clear-repro "video upload issue" this task describes, worse
    // the bigger/more-parallel the upload. Fixed by reading each
    // chunk's byte range with `file.openRead(start, end)`, which opens
    // its own file descriptor per call — concurrent chunk reads no
    // longer share any mutable position state, so no ordering between
    // them can corrupt another chunk's bytes.
    Future<List<int>> readChunk(int start, int end) async {
      final builder = BytesBuilder(copy: false);
      await for (final piece in file.openRead(start, end)) {
        builder.add(piece);
      }
      return builder.takeBytes();
    }

    // Parallel batches me upload karo (sequential ki jagah) — bade file
    // ke liye kaafi tez hota hai. Ek chunk fail ho (checksum mismatch ya
    // transient network issue) to usi chunk ko 2 baar tak retry karte hain
    // pehle poore upload ko fail maanne se — sirf X baar fail hone pe
    // exception upar jaati hai (jahan resume state safe rehti hai, agli
    // baar isi jagah se dubara try hoga).
    const maxRetriesPerChunk = 2;
    for (int batchStart = 0; batchStart < pending.length; batchStart += _parallelChunkUploads) {
      final batch = pending.skip(batchStart).take(_parallelChunkUploads).toList();
      await Future.wait(batch.map((chunkIndex) async {
        final start = chunkIndex * _chunkSize;
        final end = (start + _chunkSize < totalSize) ? start + _chunkSize : totalSize;

        Object? lastError;
        for (int attempt = 0; attempt <= maxRetriesPerChunk; attempt++) {
          try {
            // Re-read the chunk on every attempt (not just once outside
            // the loop) — cheap for a 5MB slice, and means a retry can't
            // ever resend bytes captured by a stale/racy read from an
            // earlier attempt.
            final chunkBytes = await readChunk(start, end);
            await uploadPostChunk(uploadId: uploadId!, chunkIndex: chunkIndex, chunkBytes: chunkBytes);
            lastError = null;
            break;
          } catch (e) {
            lastError = e;
            if (attempt < maxRetriesPerChunk) {
              await Future.delayed(Duration(milliseconds: 400 * (attempt + 1)));
            }
          }
        }
        if (lastError != null) throw lastError;

        completedCount++;
        reportProgress();
      }));
    }

    final result = await completePostChunkedUpload(uploadId);
    // Upload poora ho gaya — resume state ab zaroorat nahi, clear kar do.
    await prefs.remove(prefsKey);
    return result;
  }

  // Both composers (new_post.dart, quick_post.dart) read
  //   categories[].key/label, subcategories[].key/label, category_subcategory_map
  // Backend contract: GET /post/categories/ (views.py category_taxonomy).
  // This normalises whatever comes back into exactly that shape — `key`
  // falls back to `value`, a missing/oddly-typed subcategories part becomes
  // an empty list — so a shape drift can never again turn into the string
  // "null" being sent as `category` or a TypeError that empties the picker.
  Map<String, dynamic> _normalizeTaxonomy(dynamic raw) {
    final d = raw is Map ? raw : const {};
    List<Map<String, dynamic>> pick(dynamic list) {
      final out = <Map<String, dynamic>>[];
      if (list is! List) return out;
      for (final e in list) {
        if (e is! Map) continue;
        final key = (e['key'] ?? e['value'])?.toString();
        if (key == null || key.isEmpty) continue;
        out.add({'key': key, 'label': (e['label'] ?? key).toString()});
      }
      return out;
    }

    final map = <String, dynamic>{};
    final rawMap = d['category_subcategory_map'];
    if (rawMap is Map) {
      rawMap.forEach((k, v) {
        map[k.toString()] = v is List ? v.map((x) => x.toString()).toList() : <String>[];
      });
    }
    return {
      'categories': pick(d['categories']),
      'subcategories': pick(d['subcategories']),
      'category_subcategory_map': map,
    };
  }

  // Category + subcategory tree, taaki dropdown backend ke actual
  // CATEGORY_CHOICES / SUBCATEGORY_CHOICES / CATEGORY_SUBCATEGORY_MAP se match kare.
  Future<Map<String, dynamic>> getCategoryTaxonomy() async {
    try {
      final url = Uri.parse('${Api.baseUrl}/post/categories/');
      final response = await http.get(url, headers: {'Content-Type': 'application/json'});
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        final taxonomy = _normalizeTaxonomy(data['data']);
        if ((taxonomy['categories'] as List).isEmpty) {
          throw Exception('Category list is empty');
        }
        return taxonomy;
      } else {
        throw Exception(data['message'] ?? 'Failed to load categories');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  // TASK 3 (production_readiness_tasks.md) — feed personalization chip
  // picker. Backend contract: GET /post/interests/ (views.py
  // UserInterestsAPIView.get) -> {selected_categories: [...], categories:
  // [{key,label,selected}, ...]}. Returns the raw `categories` list so the
  // interests screen doesn't need a second call to getCategoryTaxonomy().
  Future<List<Map<String, dynamic>>> getMyInterests() async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final url = Uri.parse('${Api.baseUrl}/post/interests/');
    final response = await http.get(url, headers: {'Authorization': 'Bearer $token'});
    final data = jsonDecode(response.body);
    if (response.statusCode == 200 && data['success'] == true) {
      final list = (data['data']?['categories'] as List?) ?? const [];
      return list
          .whereType<Map>()
          .map((e) => {
                'key': (e['key'] ?? '').toString(),
                'label': (e['label'] ?? e['key'] ?? '').toString(),
                'selected': e['selected'] == true,
              })
          .toList();
    }
    throw Exception(data['message'] ?? 'Failed to load interests');
  }

  // Replaces the caller's full interest set in one call — the interests
  // screen sends every currently-toggled-on chip together, not one
  // add/remove call per chip. Backend contract: PUT /post/interests/
  // (views.py UserInterestsAPIView.put), body {"categories": [...]}.
  Future<void> updateMyInterests(List<String> categoryKeys) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final url = Uri.parse('${Api.baseUrl}/post/interests/');
    final response = await http.put(
      url,
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'categories': categoryKeys}),
    );
    final data = jsonDecode(response.body);
    if (!(response.statusCode == 200 && data['success'] == true)) {
      throw Exception(data['message'] ?? 'Failed to update interests');
    }
  }

  // TASK G4 (growth_and_feature_tasks.md) — feed video watch progress, so
  // the backend's HomeFeedView/ExploreFeedAPIView can rank by real
  // video-completion-rate instead of just views_count. Best-effort by
  // design: called from _MediaCarousel (home.dart) on pause/dispose, not
  // per-frame, and a failure here should never interrupt playback — the
  // caller wraps this in try/catch and ignores the result.
  // Backend: POST /post/<id>/video-progress/ (views.py PostVideoProgressAPIView).
  Future<void> reportVideoProgress(String postId, double watchedSeconds) async {
    final token = await AuthService.getValidToken();
    if (token == null) return;
    final url = Uri.parse('${Api.baseUrl}/post/$postId/video-progress/');
    await http.post(
      url,
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'watched_seconds': watchedSeconds}),
    );
  }

  // 🔥 NAYA — Freesound music search (media editor "Add Music" feature).
  // Backend `/post/music/search/` sirf CC0-licensed (copyright-free)
  // results deta hai — key kabhi bhi app me nahi aati, backend proxy
  // karta hai. Har result: {id, name, artist, duration, preview_url,
  // license: 'CC0', tags}.
  Future<List<Map<String, dynamic>>> searchFreesoundMusic(String query, {int page = 1}) async {
    try {
      final token = await AuthService.getValidToken();
      final url = Uri.parse('${Api.baseUrl}/post/music/search/')
          .replace(queryParameters: {'q': query, 'page': '$page'});
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (token != null) 'Authorization': 'Bearer $token',
        },
      );
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        return List<Map<String, dynamic>>.from(data['data']['results'] ?? []);
      } else {
        throw Exception(data['message'] ?? 'Music search failed');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  // 🔥 TASK 1 — real reaction toggle (like/confuse/wrong/imp/explain).
  // Same request/response contract as `HomeFeedService.toggleReaction` in
  // `services/home_api_model_service.dart` (feed's version — already
  // wired and correct), duplicated here so `post/`'s own `ApiService` is
  // the single entry point for everything `singlepost.dart` needs, same
  // as every other call in this file.
  //   POST /post/like/<post_id>/reaction/   body: {"reaction": "<type>"}
  //   → {"status", "my_reaction", "counts": {like,confuse,wrong,imp,explain,total}}
  // Same reaction sent twice = unlike (handled server-side); a different
  // reaction = change. Caller should optimistically update UI and roll
  // back on failure — see `singlepost.dart`'s `_handleReaction`.
  Future<Map<String, dynamic>> toggleReaction(String postId, String reaction) async {
    final token = await AuthService.getValidToken();
    if (token == null) throw Exception('User not logged in');
    final url = Uri.parse('${Api.baseUrl}/post/like/$postId/reaction/');
    final response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'reaction': reaction}),
    );
    if (response.statusCode == 200) return jsonDecode(response.body);
    final data = jsonDecode(response.body);
    throw Exception(data['message'] ?? data['error'] ?? 'Reaction failed: ${response.statusCode}');
  }

  // --- YE NAYA METHOD ADD HUA HAI, ISKI WAJAH SE ERROR AA RAHA THA ---
  Future<Map<String, dynamic>> getPostById(String postId) async {
    try {
      final token = await AuthService.getValidToken();
      final url = Uri.parse("${Api.baseUrl}/post/details/$postId/");

      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (token!= null) 'Authorization': 'Bearer $token',
        },
      );

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        return data['data'];
      } else {
        throw Exception(data['message']?? 'Post not found');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}