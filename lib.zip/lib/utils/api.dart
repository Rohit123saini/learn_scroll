class Api {
  static const String baseUrl = "http://10.26.136.189:8000";
  // static const String baseUrl = "https://learn-scroll-onl4.onrender.com";
}