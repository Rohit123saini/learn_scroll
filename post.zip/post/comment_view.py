#post/comment_view.py
# NOTE (cleanup, post_app.md — dead code, not a "known issue" but worth
# flagging): the original file had ~326 lines of an OLDER, fully
# commented-out version of everything below (CommentCreateAPIView,
# chunked_upload_init/_chunk/_complete, CommentUpdateAPIView,
# CommentDeleteAPIView, CommentListAPIView, CommentRepliesAPIView,
# CommentHideAPIView) sitting above the real, active definitions of the
# exact same classes/functions. Python just skips commented lines, so it
# was harmless at runtime -- but it's confusing for anyone reading the
# file cold, bloats git-blame/diffs, and risks someone editing the DEAD
# copy by mistake thinking they fixed something. Removed here; the live
# code below is untouched and behaves identically to before.
import os
import uuid
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F, Count
from django.db.models.functions import Greatest
from django.shortcuts import get_object_or_404
from django.utils import timezone

from rest_framework.views import APIView
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from drf_spectacular.utils import extend_schema, OpenApiParameter

from.models import Post, PostComment, CommentMedia, ChunkedUpload, PostChunkedUpload, CommentLike
from.comment_serializers import CreateCommentSerializer, PostCommentSerializer
from .services import notify_post_commented, save_uploaded_chunk, assemble_chunks, hidden_commenter_ids

def get_media_type(file):
    content_type = getattr(file, 'content_type', '') or ''
    name = (getattr(file, 'name', '') or '').lower()
    if content_type.startswith('image/') or name.endswith(('.png', '.jpg', '.jpeg', '.webp', '.gif', '.heic')):
        return 'image'
    if content_type.startswith('video/') or name.endswith(('.mp4', '.mov', '.avi', '.mkv', '.webm')):
        return 'video'
    if content_type.startswith('audio/') or name.endswith(('.mp3', '.wav', '.m4a', '.ogg', '.aac', '.opus')):
        return 'audio'
    if name.endswith(('.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.zip', '.txt', '.csv')):
        return 'document'
    return 'other'

class CommentCreateAPIView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    @extend_schema(summary="Create Comment or Reply - Any file upto 4GB", tags=['Comments'])
    @transaction.atomic
    def post(self, request):
        data_dict = {}
        for key in request.data.keys():
            if key!= 'files':
                data_dict[key] = request.data.get(key)

        if data_dict.get('parent_id') in ['', 'string', 'null', 'None', None]:
            data_dict['parent_id'] = None
        if data_dict.get('post_id') in ['', 'string', 'null', None]:
            data_dict['post_id'] = None

        serializer = CreateCommentSerializer(data=data_dict)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        parent = None
        if data.get('parent_id'):
            parent = get_object_or_404(PostComment, id=data['parent_id'], is_deleted=False)
            post = parent.post
            # FIX 2 - Multiple nesting allow kar diya, ye block hata diya
            # if parent.parent_id is not None:
            # return Response({"error": "Only 1 level nesting allowed"}, status=400)
        else:
            post = get_object_or_404(Post, id=data['post_id'])

        if post.is_comments_disabled:
            return Response({"error": "Comments disabled"}, status=403)

        files = [f for f in request.FILES.getlist('files') if hasattr(f, 'size')]
        if not files:
            files = [f for f in request.FILES.getlist('file') if hasattr(f, 'size')]

        content = data.get('content', '').strip()
        if not content and not files:
            return Response({"error": "Content or file is required"}, status=400)

        comment = PostComment.objects.create(post=post, user=request.user, parent=parent, content=content)

        for f in files[:5]:
            CommentMedia.objects.create(
                comment=comment,
                media_type=get_media_type(f),
                file=f,
                file_size=f.size,
                mime_type=getattr(f, 'content_type', '')
            )

        # Task 24 CORRECTION — see models.py's own note (search
        # "update_comments_count REMOVED ENTIRELY") for why this manual
        # F() update belongs here and NOT in a signal. A previous pass on
        # this file did the opposite — added a signal-based
        # `update_comments_count` and removed this manual update — which
        # re-introduces exactly the bug models.py documents fixing: this
        # is a soft-delete-based app, so a signal recomputing/adjusting
        # `comments_count` on every PostComment save can't distinguish
        # "new comment", "content edit", and "hide/unhide toggle" without
        # a lot of fragile state-tracking, whereas the manual +1/-1 here
        # (mirrored by CommentDeleteAPIView's -1) is simple and already
        # correct — same pattern `replies_count` has always used safely.
        # `post/signals.py` deliberately has NO PostComment receiver.
        if parent:
            PostComment.objects.filter(id=parent.id).update(replies_count=F('replies_count') + 1)
        else:
            Post.objects.filter(id=post.id).update(comments_count=F('comments_count') + 1)
            # Task 11 fix — only a new TOP-LEVEL comment notifies the post
            # owner (matches notify_post_commented()'s own docstring); a
            # reply to another comment doesn't spam the post owner for
            # every sub-thread reply.
            notify_post_commented(post, comment)

        return Response(PostCommentSerializer(comment, context={'request': request}).data, status=201)

# ================= 4GB CHUNKED UPLOAD =================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([JSONParser, MultiPartParser, FormParser])
def chunked_upload_init(request):
    try:
        file_name = request.data.get('file_name')
        total_chunks = int(request.data.get('total_chunks', 0))
        total_size = int(request.data.get('total_size', 0))
        post_id = request.data.get('post_id')
        parent_id = request.data.get('parent_id')

        if parent_id in ['', 'null', 'None']:
            parent_id = None

        if total_size > 4294967296:
            return Response({"error": "File too large. Max 4GB allowed"}, status=400)

        if not file_name or (not post_id and not parent_id) or total_chunks == 0:
            return Response({"error": "file_name, post_id, total_chunks required"}, status=400)

        # FIX (post_app.md §14 issue #7): ChunkedUpload.post_id/parent_id
        # are plain CharFields (no DB-level FK — see models.py's own note
        # on why: validated in the view instead, kept deliberately loose
        # at the model layer). Before this fix, `chunked_upload_init`
        # never explicitly checked that the target actually existed — a
        # stale/invalid post_id or parent_id would sail through init(),
        # get stored as-is on the ChunkedUpload row, and only surface as
        # a 404 in `chunked_upload_complete`'s own get_object_or_404
        # calls, AFTER the client had already spent time/bandwidth
        # pushing every chunk. This is a dedicated, explicit existence
        # check — separate from (and running before) the §14 issue #10
        # `is_comments_disabled` check below — with a field-specific
        # error message so the client knows exactly which of
        # `post_id`/`parent_id` was bad, rather than a generic 400 from
        # letting Http404 fall through to the blanket `except Exception`
        # at the bottom of this view.
        if parent_id:
            try:
                parent_comment = PostComment.objects.get(id=parent_id, is_deleted=False)
            except (PostComment.DoesNotExist, ValueError, ValidationError):
                return Response({"error": "Invalid parent_id: comment not found"}, status=400)
            target_post = parent_comment.post
        else:
            try:
                target_post = Post.objects.get(id=post_id)
            except (Post.DoesNotExist, ValueError, ValidationError):
                return Response({"error": "Invalid post_id: post not found"}, status=400)

        # FIX (post_app.md §14 issue #10): the regular CommentCreateAPIView
        # already blocks new comments on a post with `is_comments_disabled`,
        # but this chunked-upload path (used for large video comments)
        # never checked it — someone could still start (and finish) a 4GB
        # video-comment upload on a post whose owner explicitly disabled
        # comments. Checked here, at `init` time (reusing the same
        # target_post/parent_comment the existence check above already
        # resolved — no second query), so a blocked upload fails
        # immediately instead of after the client has already spent time/
        # bandwidth pushing chunks.
        if target_post.is_comments_disabled:
            return Response({"error": "Comments disabled"}, status=403)

        upload_id = str(uuid.uuid4())
        ChunkedUpload.objects.create(
            upload_id=upload_id,
            file_name=file_name,
            total_chunks=total_chunks,
            total_size=total_size,
            post_id=post_id if post_id else None,
            parent_id=parent_id,
            content=request.data.get('content', ''),
            user=request.user
        )
        os.makedirs(os.path.join(settings.MEDIA_ROOT, 'temp_chunks', upload_id), exist_ok=True)
        return Response({"upload_id": upload_id, "message": "Ready for chunks"}, status=200)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return Response({"error": str(e)}, status=400)

# TASK 3 — this endpoint is deliberately shared by BOTH the comment
# chunked-upload flow AND the new post chunked-upload flow. Chunk upload
# genuinely doesn't care which kind of thing the finished file will
# become — it only needs an upload_id + chunk_index + the bytes — so
# api_service.dart's uploadPostChunk() posts here (/post/comment/chunked/
# chunk/) on purpose instead of a separate /post/chunked/chunk/ route (see
# that file's own comment). What's new below is the lookup: an upload_id
# now might belong to `ChunkedUpload` (comment) or `PostChunkedUpload`
# (post) — previously this only ever checked `ChunkedUpload`, so every
# post-initiated chunk 404'd the moment views.py's post_chunked_upload_init
# started creating `PostChunkedUpload` rows instead. Also now verifies the
# optional `chunk_hash` (MD5) field api_service.dart's post flow sends with
# every chunk — previously accepted and silently ignored, so a corrupted
# chunk in transit would get baked straight into the final assembled file
# with no way to catch it before the whole 4GB stitch-together happened.
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser])
def chunked_upload_chunk(request):
    try:
        upload_id = request.data.get('upload_id')
        chunk_index = request.data.get('chunk_index')
        chunk_file = request.FILES.get('chunk')
        chunk_hash = request.data.get('chunk_hash') or None

        if not upload_id or chunk_file is None:
            return Response({"error": "upload_id and chunk file required"}, status=400)

        try:
            chunk_index = int(chunk_index)
        except (TypeError, ValueError):
            return Response({"error": "chunk_index must be int"}, status=400)

        upload = ChunkedUpload.objects.filter(upload_id=upload_id, user=request.user).first()
        if upload is None:
            upload = get_object_or_404(PostChunkedUpload, upload_id=upload_id, user=request.user)

        try:
            save_uploaded_chunk(upload_id, chunk_index, chunk_file, expected_hash=chunk_hash)
        except ValueError:
            return Response({"error": f"Chunk {chunk_index} hash mismatch"}, status=400)

        progress = int(((chunk_index + 1) / upload.total_chunks) * 100)
        return Response({"received": chunk_index, "progress": progress}, status=200)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return Response({"error": str(e)}, status=400)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([JSONParser, MultiPartParser, FormParser])
@transaction.atomic
def chunked_upload_complete(request):
    try:
        upload_id = request.data.get('upload_id')
        if not upload_id:
            return Response({"error": "upload_id required"}, status=400)

        upload = get_object_or_404(ChunkedUpload, upload_id=upload_id, user=request.user)

        # Task 13 fix — re-check is_comments_disabled here too, not just
        # at init(). init's check (see chunked_upload_init's own FIX
        # comment above) only guards the START of what can be a
        # long-running, multi-request upload (up to 4GB) — the post
        # owner can flip is_comments_disabled at any point during that
        # window, and complete() used to resolve post/parent (and create
        # the comment) without ever looking at the flag again. Resolved
        # and checked here, BEFORE assembling the chunks into the final
        # file (not after), so a now-blocked upload fails cheaply instead
        # of first paying the disk I/O to stitch together a multi-GB file
        # it's about to reject anyway. `post`/`parent` are reused below
        # instead of being re-queried a second time after assembly.
        #
        # FIX (post_app.md §14 issue #7): the get_object_or_404 calls
        # below are now a defense-in-depth backstop, not the primary
        # existence check — `chunked_upload_init` validates post_id/
        # parent_id up front (see its own FIX comment), so a stale ID
        # normally never gets this far. They stay here because the two
        # calls are separated by however long the chunk-push phase takes
        # — the target Post/Comment could still be deleted mid-upload —
        # and because this view is reachable with any `upload_id` a
        # caller has, independent of whether init's check already ran
        # for it in this process.
        if upload.parent_id:
            parent = get_object_or_404(PostComment, id=upload.parent_id)
            post = parent.post
        else:
            parent = None
            post = get_object_or_404(Post, id=upload.post_id)
        if post.is_comments_disabled:
            return Response({"error": "Comments disabled"}, status=403)

        # TASK 3 — assembly itself (verify every chunk present, stitch
        # them together, clean up temp_chunks/<upload_id>/) is now shared
        # with the post chunked-upload flow via Services.assemble_chunks;
        # everything below (building the PostComment/CommentMedia rows)
        # stays comment-specific and unchanged.
        final_dir = os.path.join(settings.MEDIA_ROOT, 'comment_media', str(timezone.now().year), f"{timezone.now().month:02d}", f"{timezone.now().day:02d}")
        final_file_name = f"{uuid.uuid4()}_{upload.file_name}"
        try:
            final_path = assemble_chunks(upload_id, upload.total_chunks, final_dir, final_file_name)
        except FileNotFoundError as e:
            return Response({"error": str(e)}, status=400)

        comment = PostComment.objects.create(
            post=post, user=request.user, parent=parent, content=upload.content or ""
        )

        relative_path = os.path.relpath(final_path, settings.MEDIA_ROOT)
        dummy = type('obj', (object,), {'name': final_file_name, 'content_type': 'video/mp4'})()
        media_type = get_media_type(dummy)
        if final_file_name.lower().endswith(('.mp4','.mov','.mkv')):
            media_type = 'video'

        CommentMedia.objects.create(
            comment=comment,
            media_type=media_type,
            file=relative_path,
            file_size=upload.total_size,
            mime_type='video/mp4' if media_type=='video' else 'application/octet-stream'
        )

        # Task 24 CORRECTION — same reasoning as CommentCreateAPIView.post()
        # above: the manual F() update belongs here (matches models.py's
        # documented decision), there is no comments_count signal.
        if parent:
            PostComment.objects.filter(id=parent.id).update(replies_count=F('replies_count') + 1)
        else:
            Post.objects.filter(id=post.id).update(comments_count=F('comments_count') + 1)
            # Task 11 fix — same top-level-only notify as the regular
            # CommentCreateAPIView path above; a large video comment
            # finished via chunked upload is still a new top-level
            # comment and should notify the post owner the same way.
            notify_post_commented(post, comment)

        upload.is_completed = True
        upload.save(update_fields=['is_completed'])

        return Response(PostCommentSerializer(comment, context={'request': request}).data, status=201)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return Response({"error": str(e)}, status=500)

# ================= COMMENT REACTION - 5 TYPES =================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def comment_react(request, comment_id):
    comment = get_object_or_404(PostComment, id=comment_id, is_deleted=False)
    reaction = request.data.get('reaction', 'like')
    if reaction not in ['like','confuse','wrong','imp','explain']:
        return Response({"error":"Invalid reaction"}, status=400)

    like, created = CommentLike.objects.get_or_create(
        comment=comment, user=request.user,
        defaults={'reaction_type': reaction}
    )
    if not created:
        if like.reaction_type == reaction:
            like.delete()
            my_reaction = None
        else:
            like.reaction_type = reaction
            like.save()
            my_reaction = reaction
    else:
        my_reaction = reaction

    qs = CommentLike.objects.filter(comment=comment).values('reaction_type').annotate(c=Count('id'))
    counts = {r['reaction_type']: r['c'] for r in qs}
    data = {
        'like': counts.get('like',0),
        'confuse': counts.get('confuse',0),
        'wrong': counts.get('wrong',0),
        'imp': counts.get('imp',0),
        'explain': counts.get('explain',0),
        'total': sum(counts.values())
    }
    return Response({"my_reaction": my_reaction, "myReaction": my_reaction, "counts": data, "reaction_counts": data})

# ================= UPDATE - FIXED FOR EDIT =================
class CommentUpdateAPIView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    @extend_schema(summary="Edit Comment", tags=['Comments'])
    @transaction.atomic
    def patch(self, request, comment_id):
        comment = get_object_or_404(PostComment, id=comment_id, is_deleted=False)
        if comment.user!= request.user:
            return Response({"error": "Not allowed"}, status=403)

        # FIX 1 - JSON aur FormData dono se content lo
        content = request.data.get('content', None)
        if content is None:
            content = request.data.get('content', '')

        if content is not None and str(content).strip()!= "":
            comment.content = str(content).strip()
            comment.is_edited = True
            comment.save(update_fields=['content', 'is_edited', 'updated_at'])
        elif content is not None and str(content).strip() == "":
            # agar empty bheja to bhi edited mark karo
            comment.is_edited = True
            comment.save(update_fields=['is_edited', 'updated_at'])

        # getlist safe handling
        remove_ids = []
        if hasattr(request.data, 'getlist'):
            remove_ids = request.data.getlist('remove_media_ids')
        if remove_ids:
            CommentMedia.objects.filter(comment=comment, id__in=remove_ids).delete()

        for f in request.FILES.getlist('files')[:5]:
            CommentMedia.objects.create(
                comment=comment,
                media_type=get_media_type(f),
                file=f,
                file_size=f.size,
                mime_type=getattr(f, 'content_type', '')
            )

        return Response(PostCommentSerializer(comment, context={'request': request}).data)

class CommentDeleteAPIView(APIView):
    permission_classes = [IsAuthenticated]
    @transaction.atomic
    def delete(self, request, comment_id):
        comment = get_object_or_404(PostComment, id=comment_id, is_deleted=False)
        if comment.user!= request.user and not request.user.is_staff:
            return Response({"error": "Not allowed"}, status=403)
        comment.is_deleted = True
        comment.deleted_at = timezone.now()
        comment.save(update_fields=['is_deleted', 'deleted_at'])
        # Task 24 CORRECTION — restored. models.py explicitly documents
        # removing the old `update_comments_count` signal *because* this
        # manual decrement (mirroring the manual +1 in
        # CommentCreateAPIView) is the correct, intended mechanism — see
        # that file's "update_comments_count REMOVED ENTIRELY" note.
        # CommentHideAPIView's own separate manual comments_count
        # adjustment (below) is unrelated — it toggles is_hidden, not
        # is_deleted — and stays exactly as-is.
        if comment.parent_id:
            PostComment.objects.filter(id=comment.parent_id).update(replies_count=Greatest(F('replies_count') - 1, 0))
        else:
            Post.objects.filter(id=comment.post_id).update(comments_count=Greatest(F('comments_count') - 1, 0))
        return Response({"message": "Comment deleted"}, status=200)

class CommentListAPIView(APIView):
    permission_classes = [AllowAny]

    # TASK G5 (growth_and_feature_tasks.md) — "Comments & reactions parity
    # with mainstream apps". The reaction model (5 types, CommentLike) and
    # nested replies (PostComment.parent, CommentRepliesAPIView below)
    # already existed before this task — the one real gap was sorting:
    # comments only ever came back newest-first, with no way to surface
    # the most-reacted-to ones first the way Instagram/YouTube do by
    # default. `?sort=top` (the new default) orders by `likes_count` —
    # already the TOTAL reaction count across all 5 types, not just
    # 'like' (see models.py's update_comment_reaction_counts) — so it's
    # genuinely "most reacted to", not just "most liked". `?sort=newest`
    # keeps the old chronological behavior for anyone who wants it.
    @extend_schema(
        summary="List top-level comments for a post",
        parameters=[
            OpenApiParameter(
                name='sort', type=str, required=False,
                description="'top' (default, most-reacted first) or 'newest' (chronological).",
            ),
        ],
        tags=['Comments'],
    )
    def get(self, request, post_id):
        post = get_object_or_404(Post, id=post_id)
        qs = PostComment.objects.filter(post=post, parent__isnull=True, is_deleted=False).select_related('user').prefetch_related('media')
        if not request.user.is_authenticated or request.user.id!= post.user_id:
            qs = qs.filter(is_hidden=False)
        # RestrictUser (issue #2): the post owner's restricted users' comments
        # are hidden from everyone except the commenter themself.
        viewer_id = request.user.id if request.user.is_authenticated else None
        hidden_ids = hidden_commenter_ids(post.user_id, viewer_id)
        if hidden_ids:
            qs = qs.exclude(user_id__in=hidden_ids)
        sort = (request.query_params.get('sort') or 'top').lower()
        if sort == 'newest':
            comments = qs.order_by('-is_pinned', '-created_at')[:50]
        else:
            comments = qs.order_by('-is_pinned', '-likes_count', '-created_at')[:50]
        serializer = PostCommentSerializer(comments, many=True, context={'request': request})
        return Response(serializer.data)

class CommentRepliesAPIView(APIView):
    permission_classes = [AllowAny]

    # TASK G5 — same `?sort=` support as CommentListAPIView, but the
    # default stays 'oldest' (chronological) here on purpose: replies
    # inside a thread read as a conversation, so re-ordering them by
    # reaction count (like Instagram/YouTube do for top-level comments)
    # would scramble who's replying to whom. Pass `?sort=top` explicitly
    # if a thread's UI wants that instead.
    @extend_schema(
        summary="List replies to a comment",
        parameters=[
            OpenApiParameter(
                name='sort', type=str, required=False,
                description="'oldest' (default, chronological) or 'top' (most-reacted first).",
            ),
        ],
        tags=['Comments'],
    )
    def get(self, request, comment_id):
        parent = get_object_or_404(PostComment, id=comment_id, is_deleted=False)
        sort = (request.query_params.get('sort') or 'oldest').lower()
        order = ('-likes_count', 'created_at') if sort == 'top' else ('created_at',)
        # FIX 2 - nested replies ke liye sab reply laayenge
        replies = PostComment.objects.filter(parent=parent, is_deleted=False, is_hidden=False).select_related('user').prefetch_related('media').order_by(*order)
        # RestrictUser (issue #2) — same rule as CommentListAPIView.
        viewer_id = request.user.id if request.user.is_authenticated else None
        hidden_ids = hidden_commenter_ids(parent.post.user_id, viewer_id)
        if hidden_ids:
            replies = replies.exclude(user_id__in=hidden_ids)
        serializer = PostCommentSerializer(replies, many=True, context={'request': request})
        return Response(serializer.data)

class CommentHideAPIView(APIView):
    permission_classes = [IsAuthenticated]
    @transaction.atomic
    def post(self, request, comment_id):
        comment = get_object_or_404(PostComment, id=comment_id, is_deleted=False)
        post = comment.post
        if request.user.id!= post.user_id and not request.user.is_staff:
            return Response({"error": "Only post owner can hide"}, status=403)
        comment.is_hidden = not comment.is_hidden
        if comment.is_hidden:
            comment.hidden_by = request.user
            comment.hidden_at = timezone.now()
            if comment.parent_id is None:
                Post.objects.filter(id=post.id).update(comments_count=Greatest(F('comments_count') - 1, 0))
        else:
            comment.hidden_by = None
            comment.hidden_at = None
            if comment.parent_id is None:
                Post.objects.filter(id=post.id).update(comments_count=F('comments_count') + 1)
        comment.save(update_fields=['is_hidden', 'hidden_by', 'hidden_at'])
        return Response({"message": "Hidden" if comment.is_hidden else "Unhidden", "is_hidden": comment.is_hidden})