"""
post/management/commands/backfill_media_metadata.py

1.1-BE - fill the missing width / height (image, gif, video) and
duration_seconds (video, audio) on EXISTING `PostMedia` rows. Videos uploaded
before this shipped have all three NULL, which is why the feed has to guess
their frame ratio and why Reels (needs duration_seconds > 0) skips them.

    python manage.py backfill_media_metadata --dry-run          # just count
    python manage.py backfill_media_metadata                    # enqueue to Celery, newest first
    python manage.py backfill_media_metadata --type video       # only videos (Reels first)
    python manage.py backfill_media_metadata --sync --limit 500 # run inline, no worker needed
    python manage.py backfill_media_metadata --batch-size 100 --sleep 2

Safe on a live system and to run repeatedly: the work is
`post.tasks.fill_media_metadata` (idempotent, fills only NULL columns, one
UPDATE per row); only rows that still miss something are selected, so an
interrupted run resumes by running it again; rows are walked with a
(created_at, id) keyset cursor, never OFFSET. Files ffprobe/Pillow can't read
stay NULL and are simply skipped (and logged) on every run.
"""
import time

from django.core.management.base import BaseCommand, CommandError
from django.db.models import Q

from ...models import PostMedia

SIZE_TYPES = ("image", "gif", "video")
DURATION_TYPES = ("video", "audio")


def candidate_queryset(types=None):
    """Rows that still miss a size (image/gif/video) or a duration (video/audio)."""
    missing_size = Q(media_type__in=SIZE_TYPES) & (
        Q(width__isnull=True) | Q(height__isnull=True) | Q(width=0) | Q(height=0)
    )
    missing_duration = Q(media_type__in=DURATION_TYPES) & (Q(duration_seconds__isnull=True) | Q(duration_seconds=0))
    qs = PostMedia.objects.filter(missing_size | missing_duration).exclude(file="")
    if types:
        qs = qs.filter(media_type__in=types)
    return qs


class Command(BaseCommand):
    help = "Backfill width/height/duration for existing PostMedia (1.1-BE)."

    def add_arguments(self, parser):
        parser.add_argument("--type", action="append", choices=["image", "gif", "video", "audio"],
                            help="Only this media type (repeatable). Default: all.")
        parser.add_argument("--batch-size", type=int, default=200, help="Rows fetched/queued per round (default 200).")
        parser.add_argument("--limit", type=int, default=None, help="Stop after this many rows (default: everything).")
        parser.add_argument("--sleep", type=float, default=0.0, help="Seconds to pause between batches.")
        parser.add_argument("--sync", action="store_true", help="Process in this process instead of Celery (slower).")
        parser.add_argument("--dry-run", action="store_true", help="Only report how many rows would be processed.")

    def handle(self, *args, **opts):
        batch_size, limit, sleep = opts["batch_size"], opts["limit"], opts["sleep"]
        sync, dry_run = opts["sync"], opts["dry_run"]
        if batch_size < 1:
            raise CommandError("--batch-size must be at least 1.")
        if limit is not None and limit < 1:
            raise CommandError("--limit must be at least 1.")
        if sleep < 0:
            raise CommandError("--sleep can't be negative.")

        base = candidate_queryset(opts["type"])
        total = base.count()
        target = min(total, limit) if limit else total
        self.stdout.write(f"{total} media row(s) are missing width/height/duration; will process {target}.")
        for kind in ("image", "gif", "video", "audio"):
            n = base.filter(media_type=kind).count()
            if n:
                self.stdout.write(f"  {kind}: {n}")

        if dry_run:
            self.stdout.write("Dry run - nothing queued or changed.")
            return
        if target == 0:
            self.stdout.write(self.style.SUCCESS("Nothing to do."))
            return

        from ...tasks import fill_media_metadata

        processed = filled = skipped = failed = 0
        failed_ids = []
        cursor = None
        started = time.monotonic()
        try:
            while processed < target:
                qs = base.order_by("-created_at", "-id")
                if cursor is not None:
                    ts, last_id = cursor
                    qs = qs.filter(Q(created_at__lt=ts) | Q(created_at=ts, id__lt=last_id))
                rows = list(qs.values_list("id", "created_at")[: min(batch_size, target - processed)])
                if not rows:
                    break
                for media_id, created_at in rows:
                    media_id = str(media_id)
                    if sync:
                        try:
                            if fill_media_metadata.run(media_id):
                                filled += 1
                            else:
                                skipped += 1  # unreadable / already complete / vanished (task logged why)
                        except Exception as exc:
                            failed += 1
                            failed_ids.append(media_id)
                            self.stderr.write(f"  failed {media_id}: {exc!r}")
                    else:
                        try:
                            fill_media_metadata.delay(media_id)
                            filled += 1  # = queued
                        except Exception as exc:
                            raise CommandError(
                                f"Could not queue to Celery ({exc!r}). Is the broker up? "
                                f"Re-run once it is - it only selects rows that are still missing data."
                            )
                    cursor = (created_at, media_id)
                processed += len(rows)
                self.stdout.write(f"  {processed}/{target} done ({time.monotonic() - started:.0f}s)")
                if sleep and processed < target:
                    time.sleep(sleep)
        except KeyboardInterrupt:
            self.stdout.write(self.style.WARNING("\nInterrupted. Run again - it resumes where rows are still missing data."))

        verb = "filled" if sync else "queued"
        self.stdout.write(self.style.SUCCESS(
            f"Finished: {filled} {verb}, {skipped} skipped, {failed} failed, of {processed} looked at."
        ))
        if failed_ids:
            self.stdout.write("Failed ids (first 20): " + ", ".join(failed_ids[:20]))
