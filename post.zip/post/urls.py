"""
post/urls.py

⚠️ CRITICAL FIX — the uploaded file did
`from .views import CommentDeleteView, FeedView, PostViewSet, StoryViewSet`
— **none** of these four names exist in `views.py`. `views.py` defines
`PostCreateAPIView`, `HomeFeedView`, `PostListAPIView`, `PostDetailAPIView`,
`PostReactionAPIView`, `PostSaveToggleAPIView`, `SavedPostsListAPIView`,
`serve_media_with_range`; `comment_view.py` defines
`CommentCreateAPIView`, `CommentUpdateAPIView`, `CommentDeleteAPIView`,
`CommentListAPIView`, `CommentRepliesAPIView`, `CommentHideAPIView`, plus
the chunked-upload functions and `comment_react`. This file would raise
`ImportError` on load. Rewritten against the real view names (matching
post_app.md §8), with explicit imports instead of `from .views import *`
/ `from .comment_view import *` for the same reason explicit imports were
used in every other file this session.
"""
from django.conf import settings
from django.urls import path, re_path

from . import comment_view, views
from .reels_views import ReelsFeedView
from .highlight_views import (
    HighlightAddStoryAPIView,
    HighlightDetailAPIView,
    HighlightListCreateAPIView,
    HighlightRemoveStoryAPIView,
    StoryArchiveAPIView,
)
from .close_friends_views import (
    CloseFriendCandidatesAPIView,
    CloseFriendDetailAPIView,
    CloseFriendsAPIView,
)
from .comment_view import (
    CommentCreateAPIView,
    CommentDeleteAPIView,
    CommentHideAPIView,
    CommentListAPIView,
    CommentRepliesAPIView,
    CommentUpdateAPIView,
    comment_react,
)
from .views import (
    ExploreFeedAPIView,
    FeedAdConfigAPIView,
    HashtagPostsAPIView,
    HomeFeedView,
    PostCountsAPIView,
    PostCreateAPIView,
    PostDeleteAPIView,
    PostDetailAPIView,
    PostEditAPIView,
    PostEventBulkAPIView,
    PostListAPIView,
    PostReactionAPIView,
    PostRepostAPIView,
    PostSeenBatchAPIView,
    # TASK G6 — poll voting + "Ask a doubt" answers.
    PostPollVoteAPIView,
    PostAnswerListCreateAPIView,
    PostAnswerMarkBestAPIView,
    PostVideoProgressAPIView,
    PostSaveToggleAPIView,
    PostShareAPIView,
    PostVisibilityAPIView,
    SavedPostsListAPIView,
    StoryCreateAPIView,
    StoryListAPIView,
    StoryViewAPIView,
    StoryReactAPIView,
    StoryReplyAPIView,
    StoryViewersAPIView,
    StoryDetailAPIView,
    StoryMentionCandidatesAPIView,
    StoryPollVoteAPIView,
    StoryQuestionAnswerAPIView,
    StoryStickerResponsesAPIView,
    TrendingHashtagsAPIView,
    # TASK 3 — feed personalization (production_readiness_tasks.md).
    UserInterestsAPIView,
    # Feed feedback controls (Part 1): Not interested + Mute account.
    NotInterestedAPIView,
    NotInterestedListAPIView,
    MutedAccountsAPIView,
    UnmuteAccountAPIView,
    # Feed feedback controls (Part 2): Show fewer + Why am I seeing this.
    ShowFewerAPIView,
    FeedFeedbackListAPIView,
    FeedFeedbackDeleteAPIView,
    WhyAmISeeingThisAPIView,
    serve_media_with_range,
    # TASK 3/4 — dedicated post chunked-upload routes (see views.py's own
    # comment on why these are separate from the comment chunked-upload
    # functions, and why the chunk-upload step itself is NOT among these).
    post_chunked_upload_init,
    post_chunked_upload_complete,
    post_chunked_upload_status,
    # TASK 4 — category taxonomy + Freesound music search proxy.
    category_taxonomy,
    freesound_music_search,
)

urlpatterns = [
    path("create/", PostCreateAPIView.as_view(), name="post-create"),
    path("list/", PostListAPIView.as_view(), name="post-list"),
    path("details/<uuid:id>/", PostDetailAPIView.as_view(), name="post-detail"),
    # TASK 4 — composer category/subcategory pickers were calling this
    # already; nothing existed to answer it. See category_taxonomy's own
    # docstring (views.py) for the subcategory-data caveat.
    path("categories/", category_taxonomy, name="post-categories"),
    # TASK 3 — feed personalization chip picker. GET = current selection +
    # taxonomy; PUT/POST = replace full selection.
    path("interests/", UserInterestsAPIView.as_view(), name="user-interests"),
    # Feed feedback controls (Part 1) - see NotInterestedAPIView / MutedAccountsAPIView.
    path("<uuid:post_id>/not-interested/", NotInterestedAPIView.as_view(), name="post-not-interested"),
    path("not-interested/", NotInterestedListAPIView.as_view(), name="post-not-interested-list"),
    path("muted-accounts/", MutedAccountsAPIView.as_view(), name="post-muted-accounts"),
    path("muted-accounts/<uuid:user_id>/", UnmuteAccountAPIView.as_view(), name="post-unmute-account"),
    # Feed feedback controls (Part 2) - see ShowFewerAPIView / WhyAmISeeingThisAPIView.
    path("<uuid:post_id>/show-fewer/", ShowFewerAPIView.as_view(), name="post-show-fewer"),
    path("<uuid:post_id>/why/", WhyAmISeeingThisAPIView.as_view(), name="post-why"),
    path("feedback/", FeedFeedbackListAPIView.as_view(), name="post-feedback-list"),
    path("feedback/<uuid:feedback_id>/", FeedFeedbackDeleteAPIView.as_view(), name="post-feedback-delete"),
    # TASK 4 — Music tab (media_edit_screen.dart / auto_edit_screen.dart)
    # search, proxied server-side so FREESOUND_API_KEY never ships in the app.
    path("music/search/", freesound_music_search, name="post-music-search"),
    # NEW — checklist item 57 ("create/list/delete Post") had no delete
    # route anywhere before this; soft-delete, author-or-staff.
    path("<uuid:id>/delete/", PostDeleteAPIView.as_view(), name="post-delete"),
    # NEW — post update/edit had no PATCH endpoint anywhere before this
    # (see PostEditAPIView's docstring), and a separate one for visibility
    # (Post.visibility was previously create-time-only).
    path("<uuid:id>/edit/", PostEditAPIView.as_view(), name="post-edit"),
    path("<uuid:id>/visibility/", PostVisibilityAPIView.as_view(), name="post-visibility"),
    # NEW — internal "forward to chat" (checklist item 61). See
    # PostShareAPIView / services.py's share_post_to_conversation for the
    # send_message ImportError bug this replaces.
    path("<uuid:id>/share/", PostShareAPIView.as_view(), name="post-share"),
    path("feed/", HomeFeedView.as_view(), name="home-feed"),
    # Feed "seen" signal — batch (max 50), never bumps views_count.
    path("feed/seen/", PostSeenBatchAPIView.as_view(), name="feed-seen"),
    # C1-BE — bulk analytics events (impression / dwell / tap / skip), max 100 per
    # request, throttle scope "post_events".
    path("events/", PostEventBulkAPIView.as_view(), name="post-events"),
    # Reels (vertical short videos): ranked pool, cursor + frozen snapshot, ?start=<post_id>.
    path("reels/", ReelsFeedView.as_view(), name="reels-feed"),
    path("like/<uuid:post_id>/reaction/", PostReactionAPIView.as_view(), name="post-reaction"),
    # NEW — SujhaavFayda1 item 2: bulk counts polling for currently-loaded
    # feed posts (see PostCountsAPIView docstring for the WebSocket note).
    path("counts/", PostCountsAPIView.as_view(), name="post-counts"),
    path("<uuid:post_id>/save/", PostSaveToggleAPIView.as_view(), name="post-save-toggle"),
    # NEW — Instagram-style repost. POST /post/<id>/repost/ (quick repost
    # with an empty body, "repost with caption" with `repost_caption`).
    path("<uuid:post_id>/repost/", PostRepostAPIView.as_view(), name="post-repost"),
    # TASK G6 — poll voting (live results) + "Ask a doubt" answers.
    path("<uuid:post_id>/poll/vote/", PostPollVoteAPIView.as_view(), name="post-poll-vote"),
    path("<uuid:post_id>/answers/", PostAnswerListCreateAPIView.as_view(), name="post-answers"),
    path("answers/<uuid:answer_id>/mark-best/", PostAnswerMarkBestAPIView.as_view(), name="post-answer-mark-best"),
    # TASK G4 — feed video widget reports watch progress here so
    # HomeFeedView/ExploreFeedAPIView can rank by video-completion-rate.
    path("<uuid:post_id>/video-progress/", PostVideoProgressAPIView.as_view(), name="post-video-progress"),
    path("saved/", SavedPostsListAPIView.as_view(), name="saved-posts-list"),

    # TASK 3 — chunked (large-video) post upload. Fixes api_service.dart's
    # initPostChunkedUpload/completePostChunkedUpload hitting these exact
    # paths and 404ing because they never existed before. Chunk upload
    # itself intentionally stays on the comment/chunked/chunk/ route below
    # (see views.py's post_chunked_upload_init comment) — only init/
    # complete/status are post-specific.
    path("chunked/init/", post_chunked_upload_init, name="post-chunked-init"),
    path("chunked/complete/", post_chunked_upload_complete, name="post-chunked-complete"),
    # TASK 4 — resume-status endpoint api_service.dart's
    # getChunkedUploadStatus() already calls; previously missing entirely.
    path("chunked/status/<str:upload_id>/", post_chunked_upload_status, name="post-chunked-status"),

    # NEW — SujhaavFayda1 item 3: feed ad/interstitial cadence, backend-driven
    # instead of hardcoded Dart consts.
    path("feed/ad-config/", FeedAdConfigAPIView.as_view(), name="feed-ad-config"),

    # NEW — hashtag discovery + explore/discover surface. Overview
    # table lists "Hashtag" and "Explore-content" as core responsibilities
    # of this app; neither had a queryable endpoint before this.
    path("explore/", ExploreFeedAPIView.as_view(), name="post-explore"),
    path("hashtag/<str:tag>/", HashtagPostsAPIView.as_view(), name="hashtag-posts"),
    path("hashtags/trending/", TrendingHashtagsAPIView.as_view(), name="trending-hashtags"),

    # stories — NEW (checklist items 54/55/57/60)
    path("stories/", StoryListAPIView.as_view(), name="story-list"),
    path("stories/create/", StoryCreateAPIView.as_view(), name="story-create"),
    path("stories/<uuid:story_id>/view/", StoryViewAPIView.as_view(), name="story-view"),
    path("stories/<uuid:story_id>/react/", StoryReactAPIView.as_view(), name="story-react"),
    path("stories/<uuid:story_id>/reply/", StoryReplyAPIView.as_view(), name="story-reply"),
    path("stories/<uuid:story_id>/viewers/", StoryViewersAPIView.as_view(), name="story-viewers"),
    # stickers / mentions — STORIES UPGRADE, PART 2a
    path("stories/mention-candidates/", StoryMentionCandidatesAPIView.as_view(), name="story-mention-candidates"),
    # STORIES UPGRADE - PART 3b: highlights + the archive picker.
    path("stories/archive/", StoryArchiveAPIView.as_view(), name="story-archive"),
    path("highlights/", HighlightListCreateAPIView.as_view(), name="highlight-list"),
    path("highlights/<uuid:highlight_id>/", HighlightDetailAPIView.as_view(), name="highlight-detail"),
    path("highlights/<uuid:highlight_id>/stories/", HighlightAddStoryAPIView.as_view(), name="highlight-add-story"),
    path("highlights/<uuid:highlight_id>/stories/<uuid:story_id>/", HighlightRemoveStoryAPIView.as_view(), name="highlight-remove-story"),
    # poll / question stickers - STORIES UPGRADE, PART 2b
    path("stories/<uuid:story_id>/stickers/<uuid:sticker_id>/vote/", StoryPollVoteAPIView.as_view(), name="story-poll-vote"),
    path("stories/<uuid:story_id>/stickers/<uuid:sticker_id>/answer/", StoryQuestionAnswerAPIView.as_view(), name="story-question-answer"),
    path("stories/<uuid:story_id>/stickers/<uuid:sticker_id>/responses/", StoryStickerResponsesAPIView.as_view(), name="story-sticker-responses"),
    path("stories/<uuid:story_id>/", StoryDetailAPIView.as_view(), name="story-detail"),

    # close friends — STORIES UPGRADE, PART 1
    path("close-friends/", CloseFriendsAPIView.as_view(), name="close-friends"),
    path("close-friends/candidates/", CloseFriendCandidatesAPIView.as_view(), name="close-friends-candidates"),
    path("close-friends/<int:user_id>/", CloseFriendDetailAPIView.as_view(), name="close-friend-detail"),

    # comments
    path("comment/create/", CommentCreateAPIView.as_view(), name="comment-create"),
    path("comment/<uuid:comment_id>/delete/", CommentDeleteAPIView.as_view(), name="comment-delete"),
    path("comment/post/<uuid:post_id>/", CommentListAPIView.as_view(), name="comment-list"),
    path("comment/<uuid:comment_id>/hide/", CommentHideAPIView.as_view(), name="comment-hide"),
    path("comment/<uuid:comment_id>/replies/", CommentRepliesAPIView.as_view(), name="comment-replies"),
    path("comment/chunked/init/", comment_view.chunked_upload_init, name="chunked-init"),
    path("comment/chunked/chunk/", comment_view.chunked_upload_chunk, name="chunked-chunk"),
    path("comment/chunked/complete/", comment_view.chunked_upload_complete, name="chunked-complete"),
    path("comment/<uuid:comment_id>/react/", comment_react, name="comment-react"),
    path("comment/<uuid:comment_id>/update/", CommentUpdateAPIView.as_view(), name="comment-update"),
]

# TASK 25 — production media serving.
#
# ⚠️ `serve_media_with_range` has no auth/permission checks of its own
# (see views.py notes), streams every request through a Python worker
# instead of the webserver's sendfile path, and has zero CDN/shared-cache
# in front of it. It is a local-dev convenience, not a production media
# server.
#
# Gated on `settings.SERVE_MEDIA_VIA_DJANGO` rather than bare `DEBUG` so
# ops can tell at a glance (in settings.py) exactly when this route is
# live, and so a production box that hasn't wired up nginx yet 404s
# loudly on `/media/` instead of silently working via this fallback.
# Real production media serving is nginx (`deploy/nginx.conf`, local-disk
# storage) or S3/CloudFront (`deploy/S3_CLOUDFRONT_SETUP.md`, when
# `USE_S3_STORAGE=true` — that path never even reaches this route, since
# `default_storage.url()` already points straight at S3/CloudFront).
if settings.SERVE_MEDIA_VIA_DJANGO:
    urlpatterns += [
        re_path(r"^media/(?P<path>.*)$", serve_media_with_range, name="serve-media"),
    ]