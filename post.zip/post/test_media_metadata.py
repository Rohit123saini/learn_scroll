"""
post/test_media_metadata.py - 1.1-BE tests (width / height / duration on every media row).

Run:  python manage.py test post.test_media_metadata

Needs ffmpeg + ffprobe on PATH for the video cases (they are skipped otherwise).
"""
import io
import shutil
import subprocess
import tempfile
from unittest import skipUnless

from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.management import call_command
from django.test import TestCase, override_settings
from PIL import Image

from .management.commands.backfill_media_metadata import candidate_queryset
from .models import Post, PostMedia
from .services import probe_image_dimensions, probe_video_metadata
from .tasks import fill_media_metadata

TMP_MEDIA = tempfile.mkdtemp(prefix="media_meta_")
HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def _make_user():
    return get_user_model().objects.create_user(username="meta_user", password="pw12345!", email="meta@example.com")


def _jpeg(width, height, orientation=None):
    buf = io.BytesIO()
    img = Image.new("RGB", (width, height), (10, 120, 200))
    if orientation:
        exif = img.getexif()
        exif[0x0112] = orientation
        img.save(buf, "JPEG", exif=exif)
    else:
        img.save(buf, "JPEG")
    return buf.getvalue()


def _video_bytes(size="320x180", seconds=2.4, extra=()):
    with tempfile.TemporaryDirectory() as d:
        out = f"{d}/v.mp4"
        subprocess.run(
            ["ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc=size={size}:rate=25",
             "-t", str(seconds), "-pix_fmt", "yuv420p", *extra, out],
            check=True,
        )
        return open(out, "rb").read()


@override_settings(MEDIA_ROOT=TMP_MEDIA, CELERY_TASK_ALWAYS_EAGER=False)
class MediaMetadataTests(TestCase):
    def setUp(self):
        self.user = _make_user()
        self.post = Post.objects.create(user=self.user, content="x", post_type="video", slug="meta-post")

    def _media(self, kind, name, data):
        # bulk_create skips post_save, so no Celery enqueue happens in the test.
        m = PostMedia(post=self.post, media_type=kind, file_name=name, file_size_bytes=len(data), mime_type="")
        m.file.save(name, ContentFile(data), save=False)
        PostMedia.objects.bulk_create([m])
        return PostMedia.objects.get(id=m.id)

    def test_image_dimensions_follow_exif_orientation(self):
        m = self._media("image", "a.jpg", _jpeg(400, 200, orientation=6))
        self.assertTrue(fill_media_metadata.run(str(m.id)))
        m.refresh_from_db()
        self.assertEqual((m.width, m.height), (200, 400))

    def test_does_not_overwrite_existing_values(self):
        m = self._media("image", "b.jpg", _jpeg(400, 200))
        PostMedia.objects.filter(pk=m.pk).update(width=999)
        fill_media_metadata.run(str(m.id))
        m.refresh_from_db()
        self.assertEqual(m.width, 999)
        self.assertEqual(m.height, 200)

    def test_complete_row_is_skipped(self):
        m = self._media("image", "c.jpg", _jpeg(40, 20))
        PostMedia.objects.filter(pk=m.pk).update(width=40, height=20)
        self.assertFalse(fill_media_metadata.run(str(m.id)))

    def test_unreadable_file_stays_null_without_error(self):
        m = self._media("image", "bad.jpg", b"not an image")
        self.assertFalse(fill_media_metadata.run(str(m.id)))
        m.refresh_from_db()
        self.assertIsNone(m.width)

    def test_probe_helpers_on_garbage(self):
        self.assertIsNone(probe_image_dimensions("/nonexistent/file.jpg"))

    @skipUnless(HAS_FFMPEG, "ffmpeg/ffprobe not installed")
    def test_video_size_and_duration_rounded_up(self):
        m = self._media("video", "v.mp4", _video_bytes("320x180", 2.4))
        self.assertTrue(fill_media_metadata.run(str(m.id)))
        m.refresh_from_db()
        self.assertEqual((m.width, m.height, m.duration_seconds), (320, 180, 3))

    @skipUnless(HAS_FFMPEG, "ffmpeg/ffprobe not installed")
    def test_rotated_video_reports_displayed_size(self):
        with tempfile.TemporaryDirectory() as d:
            src = f"{d}/a.mp4"
            open(src, "wb").write(_video_bytes("320x180", 1.2))
            out = f"{d}/r.mp4"
            subprocess.run(["ffmpeg", "-loglevel", "error", "-display_rotation", "90", "-i", src, "-c", "copy", out], check=True)
            meta = probe_video_metadata(out)
        self.assertEqual((meta["width"], meta["height"]), (180, 320))

    @skipUnless(HAS_FFMPEG, "ffmpeg/ffprobe not installed")
    def test_very_short_video_never_gets_zero_duration(self):
        with tempfile.TemporaryDirectory() as d:
            p = f"{d}/s.mp4"
            open(p, "wb").write(_video_bytes("64x64", 0.3))
            self.assertGreaterEqual(probe_video_metadata(p)["duration_seconds"], 1)

    @skipUnless(HAS_FFMPEG, "ffmpeg/ffprobe not installed")
    def test_backfill_command_fills_old_video_rows(self):
        m = self._media("video", "old.mp4", _video_bytes("180x320", 1.5))
        self.assertIn(m.id, set(candidate_queryset().values_list("id", flat=True)))
        call_command("backfill_media_metadata", "--sync", stdout=io.StringIO())
        m.refresh_from_db()
        self.assertEqual((m.width, m.height, m.duration_seconds), (180, 320, 2))
        self.assertNotIn(m.id, set(candidate_queryset().values_list("id", flat=True)))

    def test_backfill_dry_run_changes_nothing(self):
        m = self._media("image", "d.jpg", _jpeg(40, 20))
        call_command("backfill_media_metadata", "--dry-run", stdout=io.StringIO())
        m.refresh_from_db()
        self.assertIsNone(m.width)
